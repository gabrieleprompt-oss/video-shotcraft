# Modèle d’épisode

Le fichier `src/episode-template.ts` contient le contrat utilisé pour les prochains épisodes.

1. Choisir les scènes réutilisées et leur durée en images.
2. Écrire les textes et les données dans les props des composants existants.
3. Garder le format, la palette, la typo et les courbes du style lock.
4. Lancer `npm run validate:production` puis `npm run typecheck`.
5. Rendre d’abord un extrait court avant le rendu complet.

Le montage actuel reste dans `src/Video.tsx`, mais ses repères de scène sont désormais centralisés dans `src/production.ts`. Cela évite qu’une scène, une légende et la timeline utilisent des durées différentes.

## Schéma de contenu à remplir

```ts
createEpisode({
  id: "episode-02",
  locale: "pt-BR",
  scenes: [
    { id: "Introduction", label: "promesse", durationInFrames: 76 },
    { id: "Services", label: "fonctionnalités", durationInFrames: 94 },
    // ...
  ],
});
```

Le contenu change ; les composants et les règles de mouvement restent partagés.
