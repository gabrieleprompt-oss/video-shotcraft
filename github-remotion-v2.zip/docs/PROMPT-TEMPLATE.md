# Prompt de production réutilisable

À utiliser pour préparer un nouvel épisode dans le même format :

```text
Crée un épisode vertical 1080x1920 à 30 fps en suivant strictement le style lock
du projet Supabase reference : palette #101110/#fafafa/#35d78b, ReferenceSans et
ReferenceMono, titres centrés vers y=174, cartes à rayon 8 px, ombres douces,
sélection bleue avec poignées et courbe cubic-bezier(0.22,1,0.36,1).

Sujet : [SUJET]
Promesse en une phrase : [PROMESSE]
Langue : pt-BR
Scènes dans l’ordre :
1. [SCÈNE] — [DURÉE EN SECONDES] — [ACTION VISUELLE]
2. [SCÈNE] — [DURÉE EN SECONDES] — [ACTION VISUELLE]
3. [SCÈNE] — [DURÉE EN SECONDES] — [ACTION VISUELLE]

Réutilise les composants existants et leurs proportions. Ne crée pas de nouvelle
palette, de nouvelle police, de cartes génériques ni de transitions rebondissantes.
Les retours à la ligne des titres sont explicites. Fournis d'abord un extrait de
5 à 8 secondes et un manifeste de timeline ; le rendu complet vient après validation.
```

Le prompt fixe l’intention et le contenu. Le style lock, les composants et la porte de qualité fixent le rendu.
