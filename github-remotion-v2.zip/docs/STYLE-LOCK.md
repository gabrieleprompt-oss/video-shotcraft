# Style lock — Supabase vertical reference

Ce document est le contrat visuel de la chaîne. Un nouvel épisode peut changer son sujet, ses textes et ses données, mais il ne doit pas changer ces règles sans décision éditoriale explicite.

## Format et cadrage

- 1080 × 1920, 30 images/s, 9:16.
- Zone sûre horizontale : 48 px de chaque côté.
- Titres principaux : centrés, position supérieure autour de `y=174`, largeur utile 990 px.
- Le contenu produit reste dans l’axe central ; les grands objets 3D peuvent dépasser visuellement de la zone sûre, mais pas les textes.
- Les scènes se chevauchent de quatre images maximum pour les transitions.

## Langage visuel

- Palette sombre : `#101110` pour les scènes serveur et les arrière-plans de révélation.
- Palette claire : `#fafafa` pour les interfaces et les tableaux.
- Accent principal : `#35d78b` ; accent sombre : `#238d62`.
- Texte clair : `#f6f7f6`. Texte sombre : `#151918`.
- Sélection de mots : contour bleu `#397bc1`, remplissage bleu très léger et deux poignées rondes.
- Cartes : rayon 8 px, bordure `#edf0ed`, ombre `0 13px 26px #0002, 0 1px 3px #0001`.

## Typographie

- Sans pour les titres et les interfaces : `ReferenceSans`.
- Mono pour les labels techniques, le code et les prix : `ReferenceMono`.
- Titres : environ 80 px, interlettrage `-2.4`, interligne `1.1`.
- Labels techniques : 10 px mono, interlettrage `0.2`.
- Les retours à la ligne des titres sont décidés dans le contenu, jamais par un wrapping accidentel.

## Mouvement

- Courbe de base : cubic-bezier `(0.22, 1, 0.36, 1)`.
- Apparition courte : quatre images.
- Flou d’arrivée d’un mot : trois images maximum.
- Les objets lourds utilisent un déplacement court, une mise à l’échelle modérée et une ombre stable ; pas de rebond générique.
- Chaque scène expose ses propres fenêtres d’animation en images, afin que le rendu reste déterministe à 30 fps.

## Composants autorisés

Les épisodes réutilisent `Caption`, `ChapterBar`, `MessagesTable`, `AuthCard`, `ApiCard`, `MiniCards`, `Phone`, `FrontRack`, `PerspectiveServer`, `ProjectForm` et `Cursor`. Toute nouvelle variante doit être ajoutée comme composant paramétré ; il ne faut pas copier-coller une scène entière pour changer un texte.

## Porte de qualité

Un épisode n’est publiable qu’après : `npm run typecheck`, `npm run validate:production`, un rendu test de quelques secondes et une comparaison de photogrammes avec la référence. Le prompt peut déclencher la génération, mais ces règles empêchent une dérive silencieuse du style.
