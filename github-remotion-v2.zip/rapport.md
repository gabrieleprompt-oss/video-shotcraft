# Livraison du segment accessible

Le périmètre a été limité par l'utilisateur au premier fichier lisible. La reconstruction livrée couvre **18,866667 secondes**, soit **566 images à 30 FPS**, en **1080 × 1920**, encodage **H.264**. Les quatre images résiduelles du début de l'enregistrement ont été retirées. Aucun contenu des deux fichiers inaccessibles n'a été inventé. La fin reste sur PostgreSQL ; le fragment de phrase suivant, incomplet dans la référence, n'est pas repris.

## Contenu livré

Sept scènes React/Remotion : introduction du stack, interfaces de base de données/Auth/API, code backend, infrastructure AWS et couche Supabase, exemple de chat, création du projet, instance EC2 et ouverture sur PostgreSQL. Les scènes Infrastructure et Services regroupent les sous-étapes correspondantes. Les serveurs, ventilateurs, circuits, cartes, formulaires, téléphone, logos et titres animés sont des éléments séparés et modifiables.

Le personnage, l'interface Instagram et les barres iOS ne sont pas présents dans le rendu. Le fond est reconstruit sur tout le cadre ; l'espace inférieur est conservé libre après suppression du personnage. Il n'y a ni fond vidéo tiré de la référence, ni piste audio, ni voix synthétique.

## Vérifications effectuées

- Vérification TypeScript réussie.
- Remotion Studio démarré et ouverture de `SupabasePtBR` contrôlée dans Chromium.
- Premier contrôle sur 16 images clés, suivi de corrections du centrage des textes, des débordements, de la géométrie du stack et des transitions.
- Contrôle du rendu final à huit instants correspondants de la source : images 52, 102, 151, 236, 294, 370, 477 et 550. La planche `comparaison-reference.jpg` montre les paires référence/rendu. Elle contient naturellement l'avatar et Instagram dans la colonne de référence uniquement.
- Export final terminé avec succès. FFprobe confirme 566 images H.264, 1080 × 1920, 30 FPS, durée 18,866667 s et **aucune piste audio**.
- Décodage intégral du fichier final par FFmpeg sans erreur.

## Différences restantes

Il s'agit d'une reconstruction vectorielle, pas d'une copie pixel à pixel. Les serveurs et le stack sont redessinés en SVG avec perspective et ombrages ; les modèles 3D, la texture métallique, l'éclairage et le flou de profondeur ne sont pas identiques à ceux de l'original. Les petits pictogrammes techniques secondaires et les photos de profils du téléphone sont simplifiés. Les glyphes Supabase et PostgreSQL proviennent de Simple Icons.

La police originale n'est pas identifiée. Liberation Sans et Mono sont utilisées et incluses. Les titres portugais nécessitent des largeurs et des sauts de ligne différents. Les mouvements et apparitions suivent les scènes observées ; certains keyframes, courbes et micro-interactions restent approximatifs, issus des échantillons extraits plutôt que d'un fichier d'animation source.

`narration-pt-BR.srt` est un texte portugais minuté basé sur les phrases visibles en anglais. Il peut servir à enregistrer la voix séparément, mais ne constitue pas une transcription acoustique certifiée de la piste originale.
