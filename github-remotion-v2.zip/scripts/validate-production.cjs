const fs = require("node:fs");
const path = require("node:path");

const root = path.resolve(__dirname, "..");
const manifest = JSON.parse(fs.readFileSync(path.resolve(root, process.argv[2] ?? "timeline.json"), "utf8"));
const errors = [];

if (manifest.width !== 1080 || manifest.height !== 1920) {
  errors.push("format must remain 1080x1920");
}
if (manifest.fps !== 30) errors.push("fps must remain 30");
if (!Array.isArray(manifest.scenes) || manifest.scenes.length === 0) {
  errors.push("timeline must contain at least one scene");
}

for (const scene of manifest.scenes ?? []) {
  if (scene.toExclusive - scene.from !== scene.durationInFrames) {
    errors.push(`${scene.composition}: duration mismatch`);
  }
}
for (let i = 0; i < (manifest.scenes ?? []).length; i++) {
  for (let j = i + 1; j < manifest.scenes.length; j++) {
    const a = manifest.scenes[i];
    const b = manifest.scenes[j];
    const overlap = Math.max(0, Math.min(a.toExclusive, b.toExclusive) - Math.max(a.from, b.from));
    if (overlap > 4) errors.push(`${a.composition}/${b.composition}: overlap ${overlap} > 4`);
  }
}

if (errors.length) {
  console.error(errors.join("\n"));
  process.exit(1);
}
console.log(`production manifest OK: ${manifest.scenes.length} scenes, ${manifest.durationInFrames} frames`);
