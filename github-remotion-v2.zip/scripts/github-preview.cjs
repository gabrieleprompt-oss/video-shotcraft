const { bundle } = require("@remotion/bundler");
const { selectComposition, renderStill } = require("@remotion/renderer");
const path = require("node:path");
const fs = require("node:fs");
(async () => {
  const output = path.resolve("out/github-v2-qa");
  fs.mkdirSync(output, { recursive: true });
  const serveUrl = await bundle({ entryPoint: path.resolve("src/index.ts") });
  const options = {
    browserExecutable: "/usr/bin/chromium",
    chromeMode: "chrome-for-testing",
  };
  const composition = await selectComposition({
    serveUrl,
    id: "GithubExplainerFR",
    ...options,
  });
  const frames = process.argv.slice(2).length
    ? process.argv.slice(2).map(Number)
    : [
        1, 30, 65, 76, 96, 126, 168, 198, 235, 285, 318, 355, 404, 438, 475,
        528,
      ];
  for (let i = 0; i < frames.length; i += 2) {
    await Promise.all(
      frames.slice(i, i + 2).map(async (frame) => {
        await renderStill({
          serveUrl,
          composition,
          frame,
          output: path.join(output, `${String(frame).padStart(3, "0")}.png`),
          imageFormat: "png",
          ...options,
        });
        console.log(`preview ${frame}`);
      }),
    );
  }
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
