"""Create eight matched reference/render pairs. Uses FFmpeg, no Python dependencies."""
import argparse
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('reference', type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
out = root / 'out' / 'comparison'
out.mkdir(parents=True, exist_ok=True)
font = root / 'public/fonts/LiberationSans-Regular.ttf'

def run(*args):
    subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', *map(str,args)], check=True)

for i, frame in enumerate([52, 102, 151, 236, 294, 370, 477, 550]):
    ref = out / f'ref-{i:02d}.jpg'
    rendered = out / f'render-{i:02d}.jpg'
    run('-ss', (frame+4)/30, '-i', args.reference, '-frames:v', 1,
        '-vf', 'crop=1170:2080:0:200,scale=270:480', ref)
    run('-ss', frame/30, '-i', root/'out/supabase-pt-BR.mp4', '-frames:v', 1,
        '-vf', 'scale=270:480', rendered)
    graph = (f'[0:v][1:v]hstack,pad=540:516:0:0:color=0x222222,'
             f'drawtext=fontfile={font}:text=Reference:fontsize=16:fontcolor=white:x=12:y=489,'
             f'drawtext=fontfile={font}:text=Remotion - f{frame}:fontsize=16:fontcolor=white:x=282:y=489')
    run('-i',ref,'-i',rendered,'-filter_complex',graph,'-frames:v',1,out/f'pair-{i:02d}.jpg')
run('-start_number',0,'-i',out/'pair-%02d.jpg','-vf','tile=2x4','-frames:v',1,root/'out/comparaison-reference.jpg')
print(root/'out/comparaison-reference.jpg')
