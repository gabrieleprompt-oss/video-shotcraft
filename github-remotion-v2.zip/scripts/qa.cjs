const { bundle } = require("@remotion/bundler");
const {
  selectComposition,
  renderStill,
  openBrowser,
} = require("@remotion/renderer");
const path = require("node:path");
const fs = require("node:fs");
(async () => {
  const dir = path.resolve("out/qa");
  fs.mkdirSync(dir, { recursive: true });
  const serveUrl = await bundle({ entryPoint: path.resolve("src/index.ts") });
  const browser = {
    browserExecutable: "/usr/bin/chromium",
    chromeMode: "chrome-for-testing",
  };
  const composition = await selectComposition({
    serveUrl,
    id: "SupabasePtBR",
    ...browser,
  });
  const frames = [
    0, 24, 52, 81, 102, 122, 151, 179, 236, 260, 294, 335, 370, 423, 477, 550,
  ];
  for (let i = 0; i < frames.length; i += 2) {
    await Promise.all(
      frames.slice(i, i + 2).map(async (frame, j) => {
        await renderStill({
          serveUrl,
          composition,
          frame,
          output: path.join(
            dir,
            `${String(i + j).padStart(2, "0")}-${frame}.png`,
          ),
          imageFormat: "png",
          ...browser,
        });
        console.log(`QA frame ${frame}`);
      }),
    );
  }
  const b = await openBrowser("chrome", browser);
  try {
    const page = await b.newPage({
      context: () => null,
      logLevel: "error",
      indent: false,
      pageIndex: 0,
    });
    await page.goto({
      url: "http://localhost:3000/SupabasePtBR",
      waitUntil: "networkidle0",
      timeout: 40000,
    });
    console.log(
      "Studio:",
      await page.evaluate(() => ({
        title: document.title,
        composition: document.body.innerText.includes("SupabasePtBR"),
      })),
    );
  } finally {
    await b.close({ silent: true });
  }
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
