# Ressources et origine

Référence fournie par l'utilisateur : `ScreenRecording_10-20-2026 13-16-02_1.MOV`, durée 18,993356 s, HEVC 1170 × 2532, fréquence nominale 60 FPS. L'enregistrement contient des éléments d'interface iOS/Instagram et un avatar, retirés de la reconstruction. Il n'est pas redistribué dans l'archive du projet.

Glyphes SVG, téléchargés depuis le dépôt Simple Icons :

- https://raw.githubusercontent.com/simple-icons/simple-icons/develop/icons/supabase.svg
- https://raw.githubusercontent.com/simple-icons/simple-icons/develop/icons/postgresql.svg

Projet Simple Icons : https://github.com/simple-icons/simple-icons — CC0 pour les contributions du projet ; les marques restent la propriété de leurs titulaires. Les rendus AWS/EC2 sont redessinés en SVG dans `Hardware.tsx`.

Polices Liberation : https://github.com/liberationfonts/liberation-fonts — SIL Open Font License. Copies locales provenant des polices de la machine. Fichier de licence joint dans `public/fonts/`.
