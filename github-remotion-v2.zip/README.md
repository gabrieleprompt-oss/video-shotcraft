# Supabase — reconstruction Remotion, pt-BR

Reconstruction du **seul premier segment accessible**, à la demande de l'utilisateur. 1080 × 1920, 30 FPS, 566 images, soit 18,8667 secondes. Export H.264 sans piste audio. Les quatre premières images résiduelles de l'enregistrement sont exclues. Pas de personnage ni d'interface Instagram. Aucun extrait vidéo original n'est utilisé comme fond.

## Démarrer

Node.js 22 ou plus récent et npm. Versions utilisées ici : Node 24.19.0 / npm 11.9.0. Remotion, React et les dépendances sont verrouillés dans `package-lock.json`.

```sh
npm ci
npm run studio
```

Choisir `SupabasePtBR`. Les sept scènes graphiques sont également enregistrées individuellement. Les textes animés sont dans `src/components/Caption.tsx`. Le montage se trouve dans `src/Video.tsx`. Chaque scène est dans `src/scenes/` ; les interfaces, logos et serveurs réutilisables sont dans `src/components/`.

## Produire les épisodes suivants

Le langage visuel est verrouillé dans `src/style-lock.ts` et documenté dans `docs/STYLE-LOCK.md`. Les repères de scène et le format sont centralisés dans `src/production.ts`; `src/episode-template.ts` fournit le manifeste à remplir pour un nouvel épisode. Le prompt de production réutilisable se trouve dans `docs/PROMPT-TEMPLATE.md`.

Avant chaque rendu, lancer :

```sh
npm run validate:production
npm run typecheck
```

Le validateur bloque les changements de format, les durées incohérentes et les transitions qui se chevauchent de plus de quatre images. Les composants existants (`MessagesTable`, `AuthCard`, `ApiCard`, `Phone`, `FrontRack`, `PerspectiveServer`, etc.) sont les briques à paramétrer pour les nouveaux épisodes.

L’épisode GitHub en français est enregistré sous `GithubExplainerFR` et se rend avec :

```sh
npm run render:github:v2 -- --browser-executable=/usr/bin/chromium --chrome-mode=chrome-for-testing
```

Son script et sa timeline sont dans `github-timeline.json` et `narration-github-fr.srt`.

La version GitHub révisée dure 18 secondes (540 images). Les cinq scènes sont dans `src/github/` et possèdent chacune leur composition Studio dans le dossier `GitHub-scenes`. `Visuals.tsx` contient les briques communes : titres avec sélection bleue, dépôt, fenêtres de code, profils, surfaces en perspective et indicateur de chapitre. Le MP4 est exporté dans `out/github-explainer-fr-v2.mp4`, sans piste audio selon le format convenu.

```sh
node scripts/validate-production.cjs github-timeline.json
node scripts/github-preview.cjs
```

La première commande vérifie les durées et les chevauchements du montage GitHub ; la seconde produit les images clés dans `out/github-v2-qa/`. Le dépôt se replie avant le plan de collaboration pour conserver la continuité de l’objet ; les ajouts et retraits de code apparaissent séparément dans le plan d’historique.

## Exporter

```sh
npm run typecheck
npm run render
```

Le rendu standard utilise le navigateur géré par Remotion. Dans l'environnement Linux utilisé pour cette livraison, Chromium est déjà installé ; la commande suivante a été testée :

```sh
npm run render:linux
```

Sortie : `out/supabase-pt-BR.mp4`. Pour une autre installation de Chrome/Chromium, passer son chemin avec `--browser-executable=... --chrome-mode=chrome-for-testing`. Aucun token ni service externe n'est nécessaire pour rendre le projet après installation des dépendances.

## Contrôle des images

`node scripts/qa.cjs` génère 16 images clés dans `out/qa/` avec Chromium à `/usr/bin/chromium`. Le script vérifie aussi Studio sur son port 3000 ; lancer Studio au préalable si cette dernière vérification est souhaitée. `scripts/compare.py` crée une planche comparative lorsqu'on lui donne le chemin de la référence originale (celle-ci n'est pas incluse dans le projet).

## Texte pour la voix réalisée séparément

`narration-pt-BR.srt` contient la traduction minutée pour ce segment uniquement, basée sur les phrases anglaises visibles. Ce n'est pas une transcription acoustique vérifiée. Aucun audio n'a été synthétisé ou intégré. Les sous-titres SRT ne sont pas importés par le montage ; les titres visibles sont animés indépendamment dans React.

## Ressources

- Glyphes Supabase et PostgreSQL : Simple Icons, fichiers SVG inclus ; voir `SOURCES.md`.
- Serveurs, circuits, ventilateurs, écrans et animations : React, CSS et SVG procéduraux, modifiables dans les sources.
- Polices Liberation Sans et Mono incluses pour un rendu autonome ; licence SIL OFL incluse.

Consulter `rapport.md` pour les contrôles réalisés et les différences de fidélité restantes. Les fichiers des deux autres segments n'ont pas été utilisés.
