import { motionSpec, palette, referenceFormat, typography } from "./style-lock";

export type SceneId =
  | "Introduction"
  | "Services"
  | "Infrastructure"
  | "Chat"
  | "Creation"
  | "EC2"
  | "PostgreSQL";

export type TimelineScene = {
  id: SceneId;
  label: string;
  from: number;
  toExclusive: number;
  durationInFrames: number;
};

export type EpisodeSpec = {
  id: string;
  locale: string;
  format: typeof referenceFormat;
  style: {
    palette: typeof palette;
    typography: typeof typography;
    motion: typeof motionSpec;
  };
  scenes: readonly TimelineScene[];
};

/** The measured timing contract extracted from the readable reference segment. */
export const referenceTimeline: readonly TimelineScene[] = [
  {
    id: "Introduction",
    label: "stack Supabase",
    from: 0,
    toExclusive: 76,
    durationInFrames: 76,
  },
  {
    id: "Services",
    label: "base de dados, Auth e API",
    from: 72,
    toExclusive: 166,
    durationInFrames: 94,
  },
  {
    id: "Infrastructure",
    label: "AWS e camada Supabase",
    from: 166,
    toExclusive: 269,
    durationInFrames: 103,
  },
  {
    id: "Chat",
    label: "aplicação de chat",
    from: 269,
    toExclusive: 313,
    durationInFrames: 44,
  },
  {
    id: "Creation",
    label: "criação do projeto",
    from: 309,
    toExclusive: 406,
    durationInFrames: 97,
  },
  {
    id: "EC2",
    label: "instância EC2",
    from: 406,
    toExclusive: 524,
    durationInFrames: 118,
  },
  {
    id: "PostgreSQL",
    label: "interior e PostgreSQL",
    from: 524,
    toExclusive: 566,
    durationInFrames: 42,
  },
];

export const referenceEpisode: EpisodeSpec = {
  id: "supabase-reference-pt-BR",
  locale: "pt-BR",
  format: referenceFormat,
  style: { palette, typography, motion: motionSpec },
  scenes: referenceTimeline,
};

export const sceneTiming = (id: SceneId): TimelineScene => {
  const scene = referenceTimeline.find((item) => item.id === id);
  if (!scene) throw new Error(`Unknown reference scene: ${id}`);
  return scene;
};

export const totalDurationInFrames = referenceTimeline.reduce(
  (last, scene) => Math.max(last, scene.toExclusive),
  0,
);

export const frames = (seconds: number, fps = referenceFormat.fps) =>
  Math.round(seconds * fps);

export const seconds = (frame: number, fps = referenceFormat.fps) =>
  frame / fps;

export const overlapBetween = (a: TimelineScene, b: TimelineScene) =>
  Math.max(0, Math.min(a.toExclusive, b.toExclusive) - Math.max(a.from, b.from));

/**
 * Runtime-safe validation for generated episode manifests. This is called by
 * the CLI validation script and is also useful when adding a new episode.
 */
export const validateTimeline = (
  scenes: readonly TimelineScene[],
  maxOverlap = motionSpec.sceneOverlapFrames,
) => {
  const errors: string[] = [];
  for (const scene of scenes) {
    if (scene.toExclusive <= scene.from) {
      errors.push(`${scene.id}: end must be after start`);
    }
    if (scene.durationInFrames !== scene.toExclusive - scene.from) {
      errors.push(`${scene.id}: duration does not match its interval`);
    }
  }
  for (let i = 0; i < scenes.length; i++) {
    for (let j = i + 1; j < scenes.length; j++) {
      const overlap = overlapBetween(scenes[i], scenes[j]);
      if (overlap > maxOverlap) {
        errors.push(
          `${scenes[i].id}/${scenes[j].id}: overlap ${overlap} exceeds ${maxOverlap}`,
        );
      }
    }
  }
  return errors;
};
