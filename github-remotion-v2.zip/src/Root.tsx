import React from "react";
import { Composition, Folder, staticFile } from "remotion";
import { SupabaseVideo } from "./Video";
import { Intro } from "./scenes/Intro";
import { Services } from "./scenes/Services";
import { Infrastructure } from "./scenes/Infrastructure";
import { Chat } from "./scenes/Chat";
import { CreateProject } from "./scenes/CreateProject";
import { Instance } from "./scenes/Instance";
import { Postgres } from "./scenes/Postgres";
import { sceneTiming, totalDurationInFrames } from "./production";
import { GithubVideo } from "./GithubVideo";
import { GithubHookV2 } from "./github/Hook";
import { GithubStorageV2 } from "./github/Storage";
import { GithubCollaborationV2 } from "./github/Collaboration";
import { GithubHistoryV2 } from "./github/History";
import { GithubCommunityV2 } from "./github/Community";
export const Root = () => (
  <>
    <style>{`@font-face {font-family:ReferenceSans;src:url('${staticFile("fonts/LiberationSans-Regular.ttf")}')} @font-face {font-family:ReferenceSans;src:url('${staticFile("fonts/LiberationSans-Bold.ttf")}');font-weight:700} @font-face {font-family:ReferenceMono;src:url('${staticFile("fonts/LiberationMono-Regular.ttf")}')} * {box-sizing:border-box}`}</style>
    <Composition
      id="SupabasePtBR"
      component={SupabaseVideo}
      width={1080}
      height={1920}
      fps={30}
      durationInFrames={totalDurationInFrames}
    />
    <Composition
      id="GithubExplainerFR"
      component={GithubVideo}
      width={1080}
      height={1920}
      fps={30}
      durationInFrames={540}
    />
    <Folder name="GitHub-scenes">
      <Composition
        id="GithubHookV2"
        component={GithubHookV2}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={70}
      />
      <Composition
        id="GithubStorageV2"
        component={GithubStorageV2}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={124}
      />
      <Composition
        id="GithubCollaborationV2"
        component={GithubCollaborationV2}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={124}
      />
      <Composition
        id="GithubHistoryV2"
        component={GithubHistoryV2}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={124}
      />
      <Composition
        id="GithubCommunityV2"
        component={GithubCommunityV2}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={114}
      />
    </Folder>
    <Folder name="Scenes">
      <Composition
        id="Introduction"
        component={Intro}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={sceneTiming("Introduction").durationInFrames}
      />
      <Composition
        id="Services"
        component={Services}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={sceneTiming("Services").durationInFrames}
      />
      <Composition
        id="Infrastructure"
        component={Infrastructure}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={sceneTiming("Infrastructure").durationInFrames}
      />
      <Composition
        id="Chat"
        component={Chat}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={sceneTiming("Chat").durationInFrames}
      />
      <Composition
        id="Creation"
        component={CreateProject}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={sceneTiming("Creation").durationInFrames}
      />
      <Composition
        id="EC2"
        component={Instance}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={sceneTiming("EC2").durationInFrames}
      />
      <Composition
        id="PostgreSQL"
        component={Postgres}
        width={1080}
        height={1920}
        fps={30}
        durationInFrames={sceneTiming("PostgreSQL").durationInFrames}
      />
    </Folder>
  </>
);
