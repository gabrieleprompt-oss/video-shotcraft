import React from "react";
import { AbsoluteFill, Sequence, useVideoConfig } from "remotion";
import { GithubHookV2 } from "./github/Hook";
import { GithubStorageV2 } from "./github/Storage";
import { GithubCollaborationV2 } from "./github/Collaboration";
import { GithubHistoryV2 } from "./github/History";
import { GithubCommunityV2 } from "./github/Community";

export const GithubVideo = () => {
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill style={{ background: "#0c0f0e" }}>
      <Sequence
        from={0}
        durationInFrames={70}
        premountFor={fps}
        name="01 — GitHub, c’est quoi ?"
      >
        <GithubHookV2 />
      </Sequence>
      <Sequence
        from={66}
        durationInFrames={124}
        premountFor={fps}
        name="02 — Stocker le code"
      >
        <GithubStorageV2 />
      </Sequence>
      <Sequence
        from={186}
        durationInFrames={124}
        premountFor={fps}
        name="03 — Collaborer sur des branches"
      >
        <GithubCollaborationV2 />
      </Sequence>
      <Sequence
        from={306}
        durationInFrames={124}
        premountFor={fps}
        name="04 — Suivre et fusionner les modifications"
      >
        <GithubHistoryV2 />
      </Sequence>
      <Sequence
        from={426}
        durationInFrames={114}
        premountFor={fps}
        name="05 — Le réseau social des développeurs"
      >
        <GithubCommunityV2 />
      </Sequence>
    </AbsoluteFill>
  );
};
