import React from "react";
import {
  AbsoluteFill,
  Sequence,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { Caption } from "./components/Caption";
import { ChapterBar } from "./components/ChapterBar";
import { Intro } from "./scenes/Intro";
import { Services } from "./scenes/Services";
import { Infrastructure } from "./scenes/Infrastructure";
import { Chat } from "./scenes/Chat";
import { CreateProject } from "./scenes/CreateProject";
import { Instance } from "./scenes/Instance";
import { Postgres } from "./scenes/Postgres";
import { sceneTiming } from "./production";
export const SupabaseVideo = () => {
  const { fps } = useVideoConfig();
  const frame = useCurrentFrame();
  const introduction = sceneTiming("Introduction");
  const services = sceneTiming("Services");
  const infrastructure = sceneTiming("Infrastructure");
  const chat = sceneTiming("Chat");
  const creation = sceneTiming("Creation");
  const ec2 = sceneTiming("EC2");
  const postgres = sceneTiming("PostgreSQL");
  return (
    <AbsoluteFill
      style={{
        fontFamily: "ReferenceSans, Arial, sans-serif",
        background: "#101110",
      }}
    >
      <Sequence
        name="Introduction — stack Supabase"
        from={introduction.from}
        durationInFrames={introduction.durationInFrames}
        premountFor={fps}
      >
        <Intro />
      </Sequence>
      <Sequence
        name="Base de données, Auth et API"
        from={services.from}
        durationInFrames={services.durationInFrames}
        premountFor={fps}
      >
        <Services />
      </Sequence>
      <Sequence
        name="AWS et couche Supabase"
        from={infrastructure.from}
        durationInFrames={infrastructure.durationInFrames}
        premountFor={fps}
      >
        <Infrastructure />
      </Sequence>
      <Sequence
        name="Application de chat"
        from={chat.from}
        durationInFrames={chat.durationInFrames}
        premountFor={fps}
      >
        <Chat />
      </Sequence>
      <Sequence
        name="Création du projet"
        from={creation.from}
        durationInFrames={creation.durationInFrames}
        premountFor={fps}
      >
        <CreateProject />
      </Sequence>
      <Sequence
        name="Instance EC2"
        from={ec2.from}
        durationInFrames={ec2.durationInFrames}
        premountFor={fps}
      >
        <Instance />
      </Sequence>
      <Sequence
        name="Intérieur et PostgreSQL"
        from={postgres.from}
        durationInFrames={postgres.durationInFrames}
        premountFor={fps}
      >
        <Postgres />
      </Sequence>
      <ChapterBar frame={frame} light={frame < 309} />
      <Caption light={frame >= 74 && frame < 309} />
    </AbsoluteFill>
  );
};
