import { Easing, interpolate } from "remotion";
import { palette, typography } from "./style-lock";
export { motionSpec, palette, referenceFormat, surfaces, typography } from "./style-lock";
export const green = palette.accent;
export const ease = Easing.bezier(0.22, 1, 0.36, 1);
export const tween = (f: number, a: number, b: number, x = 0, y = 1) =>
  interpolate(f, [a, b], [x, y], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: ease,
  });
export const linear = (f: number, a: number, b: number, x = 0, y = 1) =>
  interpolate(f, [a, b], [x, y], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
export const sans = typography.sansFamily;
export const mono = typography.monoFamily;
