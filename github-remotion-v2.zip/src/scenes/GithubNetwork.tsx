import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { GithubMark } from "../components/GithubMark";
import { palette } from "../style-lock";
import { sans, tween } from "../theme";

const Node = ({ x, y, label, delay, frame, color }: { x: number; y: number; label: string; delay: number; frame: number; color: string }) => (
  <g opacity={tween(frame, delay, delay + 10)}>
    <circle cx={x} cy={y} r="28" fill={color} opacity=".15" />
    <circle cx={x} cy={y} r="13" fill={color} />
    <text x={x} y={y + 60} textAnchor="middle" fill="#d7e1db" fontSize="22" fontFamily={sans}>{label}</text>
  </g>
);

export const GithubNetwork = () => {
  const frame = useCurrentFrame();
  const rise = tween(frame, 0, 16);
  return (
    <AbsoluteFill style={{ background: palette.ink, color: palette.white }}>
      <div style={{ position: "absolute", inset: 0, background: "radial-gradient(circle at 50% 45%, #24583f 0, #101110 58%)", opacity: 0.9 }} />
      <div style={{ position: "absolute", left: 48, right: 48, top: 635, height: 560, opacity: rise, transform: `translateY(${tween(frame, 0, 16, 40, 0)}px)` }}>
        <svg viewBox="0 0 984 560" width="100%" height="100%">
          <g fill="none" stroke="#70c69d" strokeWidth="4" strokeLinecap="round" opacity=".55">
            <path d="M170 252L390 132L640 245L820 112" />
            <path d="M170 252L390 380L640 245L820 410" />
            <path d="M390 132L390 380" />
            <path d="M640 245L820 112" />
          </g>
          <Node x={170} y={252} label="commit" delay={5} frame={frame} color="#35d78b" />
          <Node x={390} y={132} label="branche" delay={12} frame={frame} color="#7aa2f7" />
          <Node x={390} y={380} label="pull request" delay={18} frame={frame} color="#d7a86e" />
          <Node x={640} y={245} label="review" delay={24} frame={frame} color="#f28b82" />
          <Node x={820} y={112} label="merge" delay={30} frame={frame} color="#8bd5ca" />
          <Node x={820} y={410} label="déploiement" delay={36} frame={frame} color="#b39ddb" />
        </svg>
      </div>
      <div style={{ position: "absolute", left: 0, right: 0, bottom: 260, display: "flex", justifyContent: "center", opacity: tween(frame, 38, 52), transform: `translateY(${tween(frame, 38, 52, 24, 0)}px)` }}>
        <GithubMark size={82} color={palette.ink} background={palette.white} />
      </div>
    </AbsoluteFill>
  );
};
