import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { PerspectiveServer } from "../components/Hardware";
import { tween } from "../theme";
export const Postgres = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{ background: "#101110" }}>
      <div style={{ position: "absolute", left: 25, top: 480, width: 1030 }}>
        <PerspectiveServer frame={118 + f} opening={tween(f, 0, 20)} />
      </div>
      <div
        style={{
          position: "absolute",
          top: 937,
          left: 158,
          width: 744,
          opacity: tween(f, 20, 32),
          translate: `0 ${tween(f, 20, 32, 25, 0)}px`,
          background: "#121e1c",
          border: "1px solid #506b5f",
          boxShadow: "0 6px 8px #0008",
          color: "#cbd4cc",
          fontSize: 22,
          padding: "8px 12px",
        }}
      >
        <b>▦ messages</b>
        <div
          style={{
            fontSize: 15,
            color: "#778b7e",
            marginTop: 7,
            fontFamily: "ReferenceMono",
          }}
        >
          id · room_id · body · user_id · created_at
        </div>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "8% 17% 35% 20% 20%",
            marginTop: 8,
            fontSize: 17,
            borderTop: "1px solid #344f40",
          }}
        >
          {["1", "1", "Olá, mundo!", "mei", "agora"].map((x) => (
            <div
              key={x}
              style={{ borderRight: "1px solid #344f40", padding: "6px 8px" }}
            >
              {x}
            </div>
          ))}
        </div>
      </div>
    </AbsoluteFill>
  );
};
