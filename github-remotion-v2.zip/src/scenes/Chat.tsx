import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { FrontRack } from "../components/Hardware";
import { MiniCards, Phone } from "../components/Interfaces";
import { tween } from "../theme";
export const Chat = () => {
  const f = useCurrentFrame();
  const shrink = tween(f, 0, 17);
  return (
    <AbsoluteFill style={{ background: "#fafafa" }}>
      <div
        style={{
          position: "absolute",
          left: 368,
          top: 575 + tween(f, 8, 23, 110, 0),
          opacity: tween(f, 8, 18),
          filter: `blur(${tween(f, 8, 20, 7, 0)}px)`,
        }}
      >
        <Phone frame={f - 10} />
      </div>
      <div
        style={{
          position: "absolute",
          left: 40 + 230 * shrink,
          top: 770 + 260 * shrink,
          width: 1000 - 460 * shrink,
        }}
      >
        <FrontRack software={1} />
      </div>
      <div
        style={{
          position: "absolute",
          left: 63 + 230 * shrink,
          top: 556 + 420 * shrink,
          scale: 1 - 0.46 * shrink,
          transformOrigin: "top left",
          opacity: 1 - tween(f, 0, 13),
        }}
      >
        <MiniCards />
      </div>
    </AbsoluteFill>
  );
};
