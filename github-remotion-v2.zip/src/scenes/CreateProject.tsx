import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { linear, tween } from "../theme";
export const Cursor = ({
  x,
  y,
  click = 0,
}: {
  x: number;
  y: number;
  click?: number;
}) => (
  <svg
    width="44"
    height="55"
    viewBox="0 0 44 55"
    style={{
      position: "absolute",
      left: x,
      top: y,
      scale: 1 - click * 0.2,
      zIndex: 9,
      filter: "drop-shadow(0 2px 2px #0007)",
    }}
  >
    <path
      d="M4 2L5 43L16 32L25 50L34 45L24 29L40 28Z"
      fill="#fff"
      stroke="#26302a"
      strokeWidth="2"
    />
  </svg>
);
export const ProjectForm = ({ frame }: { frame: number }) => {
  const name = "chatty".slice(0, Math.floor(linear(frame, 34, 52, 0, 6)));
  const dots = "•".repeat(Math.floor(linear(frame, 51, 69, 0, 15)));
  return (
    <div
      style={{
        position: "relative",
        background: "#20211f",
        color: "#f0f2ed",
        width: 980,
        padding: "35px 38px 22px",
        boxSizing: "border-box",
        boxShadow: "0 30px 50px #0005",
        borderRadius: 5,
        fontSize: 28,
      }}
    >
      <div style={{ fontSize: 39, marginBottom: 12 }}>
        Criar um novo projeto
      </div>
      <div
        style={{
          color: "#8c9189",
          fontSize: 25,
          lineHeight: 1.4,
          marginBottom: 31,
        }}
      >
        Seu projeto terá uma{" "}
        <span style={{ color: "#d9dfd5", borderBottom: "1px solid #a5aca0" }}>
          instância dedicada
        </span>
        <br />e um{" "}
        <span style={{ color: "#edf2e8", borderBottom: "1px solid #bac7b7" }}>
          banco de dados Postgres completo.
        </span>
      </div>
      {[
        [
          "Organização",
          <span key="o">
            speedy_devv{" "}
            <span style={{ float: "right", color: "#6c7669" }}>⌄</span>
          </span>,
        ],
        [
          "Nome do projeto",
          name || (
            <span key="n" style={{ color: "#484e46" }}>
              Nome do projeto
            </span>
          ),
        ],
        [
          "Senha do banco",
          dots || (
            <span key="p" style={{ color: "#484e46" }}>
              Digite uma senha forte
            </span>
          ),
        ],
        [
          "Região",
          <span key="r" style={{ fontSize: 27 }}>
            🇩🇪 Europa Central (Frankfurt)
          </span>,
        ],
      ].map(([label, value], i) => (
        <div
          key={i}
          style={{
            display: "grid",
            gridTemplateColumns: "345px 1fr",
            alignItems: "center",
            minHeight: i === 2 ? 118 : 87,
          }}
        >
          <div>{label}</div>
          <div
            style={{
              fontSize: 29,
              padding: "12px 14px",
              border: `1px solid ${i === 1 && frame >= 34 && frame < 53 ? "#467c61" : "transparent"}`,
              boxShadow:
                i === 1 && frame >= 34 && frame < 53
                  ? "0 0 6px #45926d66"
                  : undefined,
              position: "relative",
            }}
          >
            {value}
            {i === 2 && frame > 56 ? (
              <div
                style={{
                  position: "absolute",
                  left: 15,
                  right: 15,
                  bottom: -2,
                  height: 5,
                  background: "#383e36",
                }}
              >
                <div
                  style={{
                    height: 5,
                    width: `${linear(frame, 56, 70, 8, 100)}%`,
                    background: frame < 65 ? "#b3aa38" : "#38c788",
                  }}
                />
              </div>
            ) : null}
          </div>
        </div>
      ))}
      <div
        style={{
          borderTop: "1px solid #30342e",
          paddingTop: 19,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 12,
          fontSize: 24,
        }}
      >
        <span>Cancelar</span>
        <span style={{ fontSize: 18, color: "#777e73" }}>
          Você pode renomear depois
        </span>
        <div
          style={{
            background: frame > 86 ? "#248056" : "#278757",
            border: "1px solid #4daa7c",
            padding: "13px 21px",
            color: "#f1fff5",
            fontWeight: 700,
            scale: frame >= 87 && frame < 90 ? 0.97 : 1,
          }}
        >
          Criar novo projeto
        </div>
      </div>
    </div>
  );
};
export const CreateProject = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{ background: "#101110", opacity: tween(f, 0, 4) }}>
      <div
        style={{
          position: "absolute",
          left: 50,
          top: 562,
          opacity: tween(f, 0, 4),
          translate: `0 ${tween(f, 0, 6, 28, 0)}px`,
        }}
      >
        <ProjectForm frame={f} />
      </div>
      {f > 26 ? (
        <Cursor
          x={f < 69 ? linear(f, 27, 55, 720, 740) : tween(f, 69, 84, 740, 883)}
          y={f < 69 ? linear(f, 27, 55, 845, 956) : tween(f, 69, 84, 956, 1168)}
          click={f >= 87 && f < 90 ? 1 : 0}
        />
      ) : null}
    </AbsoluteFill>
  );
};
