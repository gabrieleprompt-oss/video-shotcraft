import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { GithubMark } from "../components/GithubMark";
import { palette } from "../style-lock";
import { tween } from "../theme";

export const GithubHook = () => {
  const frame = useCurrentFrame();
  const reveal = tween(frame, 0, 16);
  return (
    <AbsoluteFill
      style={{
        background: palette.ink,
        color: palette.white,
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <div
        style={{
          position: "absolute",
          inset: 0,
          background:
            "radial-gradient(circle at 50% 42%, #35d78b22, transparent 42%), linear-gradient(145deg,#101110,#1c3027)",
        }}
      />
      <div
        style={{
          position: "relative",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 42,
          opacity: reveal,
          transform: `scale(${tween(frame, 0, 18, 0.72, 1)})`,
        }}
      >
        <GithubMark size={236} color={palette.ink} background={palette.white} />
        <div
          style={{
            fontFamily: "ReferenceMono, monospace",
            fontSize: 26,
            letterSpacing: 4,
            color: palette.accent,
          }}
        >
          GITHUB / 01
        </div>
      </div>
    </AbsoluteFill>
  );
};
