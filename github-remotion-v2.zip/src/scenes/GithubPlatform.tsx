import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { GithubMark } from "../components/GithubMark";
import { ReferenceCard } from "../components/ReferenceSurface";
import { palette } from "../style-lock";
import { linear, mono, sans, tween } from "../theme";

const FileRow = ({ name, color, frame, index }: { name: string; color: string; frame: number; index: number }) => (
  <div
    style={{
      display: "flex",
      alignItems: "center",
      gap: 18,
      padding: "17px 23px",
      borderBottom: "1px solid #e6e9e6",
      opacity: tween(frame, 12 + index * 3, 17 + index * 3),
      transform: `translateX(${tween(frame, 12 + index * 3, 17 + index * 3, 24, 0)}px)`,
      fontFamily: sans,
      fontSize: 27,
      color: palette.text,
    }}
  >
    <span style={{ width: 12, height: 12, borderRadius: 3, background: color }} />
    {name}
    <span style={{ marginLeft: "auto", color: palette.quiet, fontFamily: mono, fontSize: 19 }}>main</span>
  </div>
);

export const GithubPlatform = () => {
  const frame = useCurrentFrame();
  const cardIn = tween(frame, 0, 14);
  return (
    <AbsoluteFill style={{ background: palette.paper }}>
      <div style={{ position: "absolute", left: 54, top: 560, opacity: cardIn, transform: `translateY(${tween(frame, 0, 14, 40, 0)}px)` }}>
        <ReferenceCard width={972} height={620} style={{ borderRadius: 16 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 20, padding: "22px 25px", background: "#f0f2f0", borderBottom: "1px solid #e0e4e0" }}>
            <GithubMark size={48} color={palette.white} background={palette.ink} />
            <div style={{ fontFamily: mono, fontSize: 22, color: palette.muted }}>gabriele / mon-projet</div>
            <div style={{ marginLeft: "auto", color: palette.accentDark, fontFamily: mono, fontSize: 18 }}>PUBLIC</div>
          </div>
          <div style={{ padding: "24px 28px 12px", fontFamily: sans, fontSize: 32, fontWeight: 700 }}>Code</div>
          <FileRow name="README.md" color="#8250df" frame={frame} index={0} />
          <FileRow name="app.tsx" color="#0969da" frame={frame} index={1} />
          <FileRow name="database.sql" color={palette.accentDark} frame={frame} index={2} />
          <div style={{ display: "flex", gap: 14, padding: "21px 25px", color: palette.muted, fontFamily: mono, fontSize: 18 }}>
            <span style={{ color: palette.accentDark }}>✓ 12 commits</span>
            <span>•</span>
            <span>branche main</span>
          </div>
        </ReferenceCard>
      </div>
      <div style={{ position: "absolute", left: 77, top: 1260, display: "flex", alignItems: "center", gap: 24, opacity: tween(frame, 32, 44), transform: `translateY(${tween(frame, 32, 44, 30, 0)}px)` }}>
        <div style={{ display: "flex" }}>
          {["#f28b82", "#7aa2f7", "#d7a86e", "#8bd5ca"].map((color, index) => (
            <div key={color} style={{ width: 58, height: 58, marginLeft: index ? -12 : 0, borderRadius: "50%", border: `4px solid ${palette.paper}`, background: color, display: "grid", placeItems: "center", color: palette.ink, fontFamily: mono, fontSize: 19 }}>{["A", "M", "L", "S"][index]}</div>
          ))}
        </div>
        <div style={{ fontFamily: sans, fontSize: 28, color: palette.text }}>un projet, plusieurs développeurs</div>
      </div>
      <div style={{ position: "absolute", right: 75, top: 530, opacity: tween(frame, 0, 12), transform: `rotate(${linear(frame, 0, 12, -12, 0)}deg)` }}>
        <GithubMark size={74} color={palette.white} background={palette.ink} />
      </div>
    </AbsoluteFill>
  );
};
