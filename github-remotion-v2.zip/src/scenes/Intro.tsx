import React from "react";
import { AbsoluteFill, staticFile, useCurrentFrame } from "remotion";
import { Bolt } from "../components/Logos";
import { linear, mono, tween } from "../theme";
const Cylinder = ({
  x,
  y,
  w,
  h,
  opacity = 1,
}: {
  x: number;
  y: number;
  w: number;
  h: number;
  opacity?: number;
}) => (
  <g opacity={opacity}>
    <path
      d={`M${x - w / 2} ${y}v${h}a${w / 2} ${w * 0.18} 0 0 0 ${w} 0v${-h}`}
      fill="url(#cylinder)"
      stroke="#9ba9ad"
      strokeOpacity=".3"
    />
    {[0.33, 0.66].map((v) => (
      <path
        key={v}
        d={`M${x - w / 2} ${y + h * v}a${w / 2} ${w * 0.18} 0 0 0 ${w} 0`}
        stroke="#25353a"
        strokeWidth="2"
        fill="none"
      />
    ))}
    <ellipse
      cx={x}
      cy={y}
      rx={w / 2}
      ry={w * 0.18}
      fill="#8b999e"
      stroke="#bcc6c5"
      strokeOpacity=".35"
    />
    <path
      d={`M${x - w * 0.36} ${y + 5}v${h - 10}`}
      stroke="#e8eeee"
      strokeWidth={w * 0.06}
      opacity=".13"
    />
  </g>
);
export const Intro = () => {
  const f = useCurrentFrame();
  const reveal = tween(f, 23, 37);
  const count = Math.round(linear(f, 0, 27, 878711, 1000000));
  return (
    <AbsoluteFill style={{ background: "#000" }}>
      <svg
        viewBox="0 0 1080 1500"
        style={{ position: "absolute", inset: 0, width: 1080, height: 1500 }}
      >
        <defs>
          <linearGradient id="cylinder">
            <stop stopColor="#293238" />
            <stop offset=".28" stopColor="#79898e" />
            <stop offset=".54" stopColor="#454c54" />
            <stop offset=".75" stopColor="#181f28" />
            <stop offset="1" stopColor="#78868d" />
          </linearGradient>
          <radialGradient id="introShade">
            <stop stopColor="#000" stopOpacity="0" />
            <stop offset="1" stopColor="#000" stopOpacity=".65" />
          </radialGradient>
        </defs>
        <g
          style={{
            filter: "blur(8px)",
            transformOrigin: "540px 650px",
            transform: `scale(${tween(f, 0, 34, 1, 1.4)})`,
            opacity: 1 - reveal * 0.3,
          }}
        >
          {Array.from({ length: 65 }, (_, i) => {
            const x = ((i * 197 + 71) % 1120) - 20;
            const y = 50 + ((i * 131) % 1050);
            const s = 0.2 + (y / 1300) * 0.9;
            return (
              <Cylinder
                key={i}
                x={x}
                y={y}
                w={65 * s}
                h={110 * s}
                opacity={0.2 + (i % 5) * 0.13}
              />
            );
          })}
        </g>
        <rect width="1080" height="1500" fill="url(#introShade)" />
      </svg>
      <div
        style={{
          position: "absolute",
          top: 340,
          left: 20,
          width: 1040,
          height: 1040,
        }}
      >
        <svg
          viewBox="0 0 1000 1000"
          width="100%"
          height="100%"
          style={{ overflow: "visible" }}
        >
          <defs>
            <linearGradient id="disc" x2="1" y2=".2">
              <stop stopColor="#1c2726" />
              <stop offset=".22" stopColor="#455b54" />
              <stop offset=".43" stopColor="#101d1b" />
              <stop offset=".8" stopColor="#182c25" />
              <stop offset="1" stopColor="#3e564a" />
            </linearGradient>
            <linearGradient id="pgCore">
              <stop stopColor="#173b4e" />
              <stop offset=".4" stopColor="#538aaa" />
              <stop offset=".7" stopColor="#1d3e56" />
              <stop offset="1" stopColor="#142431" />
            </linearGradient>
            <radialGradient id="groundLight">
              <stop stopColor="#79e7af" stopOpacity=".18" />
              <stop offset="1" stopColor="#17352e" stopOpacity="0" />
            </radialGradient>
          </defs>
          <g
            opacity={1 - reveal}
            transform={`translate(500 250) scale(${tween(f, 0, 23, 0.45, 1.65)}) translate(-500 -250)`}
          >
            <Cylinder x={500} y={250} w={230} h={250} />
            <ellipse
              cx="500"
              cy="565"
              rx="315"
              ry="62"
              fill="none"
              stroke="#c4e0dd"
              opacity={tween(f, 5, 20) * 0.45}
            />
          </g>
          <g
            opacity={reveal}
            transform={`translate(500 440) scale(${tween(f, 23, 42, 0.75, 1)}) translate(-500 -440)`}
          >
            <ellipse
              cx="500"
              cy="600"
              rx="474"
              ry="157"
              fill="url(#groundLight)"
            />
            {Array.from({ length: 10 }, (_, i) => (
              <path
                key={i}
                d={`M500 596L${500 + Math.cos((i * Math.PI) / 5) * 470} ${596 + Math.sin((i * Math.PI) / 5) * 160}L${500 + Math.cos(((i + 0.35) * Math.PI) / 5) * 470} ${596 + Math.sin(((i + 0.35) * Math.PI) / 5) * 160}Z`}
                fill="#496e5c"
                opacity=".15"
              />
            ))}
            <path d="M344 455v137a156 48 0 0 0 312 0V455" fill="url(#pgCore)" />
            <image
              href={staticFile("logos/postgresql.svg")}
              x="455"
              y="485"
              width="95"
              height="85"
              style={{ filter: "invert(100%)" }}
            />
            {[0, 1, 2, 3, 4, 5].map((i) => {
              const y = 180 + i * 52;
              return (
                <g
                  key={i}
                  transform={`translate(0 ${tween(f, 25 + i, 44 + i, -i * 13, 0)})`}
                >
                  <path
                    d={`M322 ${y}v30a178 20 0 0 0 356 0v-39`}
                    fill="url(#disc)"
                    stroke="#314e40"
                    strokeWidth="2"
                  />
                  <ellipse
                    cx="500"
                    cy={y}
                    rx="178"
                    ry="20"
                    fill="#12251f"
                    stroke="#699e7e"
                    strokeWidth="2"
                  />
                  {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((j) => (
                    <path
                      key={j}
                      d={`M${342 + j * 33} ${y + 14 + Math.sin((j / 9) * Math.PI) * 14}v13`}
                      stroke="#050c0a"
                      strokeWidth="4"
                    />
                  ))}
                  {[365, 425, 590, 638].map((x, j) => (
                    <g key={x}>
                      <circle
                        cx={x}
                        cy={y + 12 + Math.sin((j / 3) * Math.PI) * 13}
                        r="8"
                        fill="#65e4b2"
                        opacity=".13"
                      />
                      <circle
                        cx={x}
                        cy={y + 12 + Math.sin((j / 3) * Math.PI) * 13}
                        r="3.5"
                        fill="#97e5c5"
                      />
                    </g>
                  ))}
                </g>
              );
            })}
            <g>
              <path
                d="M306 606v41a194 49 0 0 0 388 0v-41"
                fill="url(#disc)"
                stroke="#6a9978"
              />
              <ellipse
                cx="500"
                cy="606"
                rx="194"
                ry="49"
                fill="#22382d"
                stroke="#78a98b"
              />
              {Array.from({ length: 15 }, (_, i) => (
                <path
                  key={i}
                  d={`M${325 + i * 25} ${630 + Math.sin((i / 14) * Math.PI) * 38}v17`}
                  stroke="#09130e"
                  strokeWidth="4"
                />
              ))}
            </g>
            {[
              {
                name: "Supavisor",
                x: 275,
                y: 210,
                side: -1,
                icon: "♦",
                color: "#a66edd",
              },
              {
                name: "Realtime",
                x: 275,
                y: 330,
                side: -1,
                icon: "♦",
                color: "#a66edd",
              },
              {
                name: "PostgREST",
                x: 275,
                y: 448,
                side: -1,
                icon: "♜",
                color: "#67a5be",
              },
              {
                name: "EC2",
                x: 299,
                y: 618,
                side: -1,
                icon: "▣",
                color: "#eb8b26",
              },
              {
                name: "Edge Functions",
                x: 690,
                y: 265,
                side: 1,
                icon: "◉",
                color: "#fafafa",
              },
              {
                name: "Auth",
                x: 728,
                y: 385,
                side: 1,
                icon: "∞",
                color: "#2ab8c5",
              },
              {
                name: "Postgres",
                x: 709,
                y: 530,
                side: 1,
                icon: "♘",
                color: "#64a7c4",
              },
            ].map((v, i) => (
              <g key={v.name} opacity={tween(f, 33 + i * 2, 43 + i * 2)}>
                <path
                  d={`M${v.x} ${v.y}h${v.side * -35}`}
                  stroke="#889b91"
                  strokeWidth="2"
                />
                <circle
                  cx={v.x}
                  cy={v.y}
                  r="10"
                  fill="#14231d"
                  stroke="#8ea99c"
                />
                <circle cx={v.x} cy={v.y} r="4" fill="#d8ffee" />
                <text
                  x={v.x + v.side * 54}
                  y={v.y + 10}
                  textAnchor={v.side > 0 ? "start" : "end"}
                  fontSize="27"
                  fill="#e4eeeb"
                  fontWeight="700"
                >
                  {v.side > 0 ? <tspan fill={v.color}>{v.icon} </tspan> : null}
                  {v.name}
                  {v.side < 0 ? <tspan fill={v.color}> {v.icon}</tspan> : null}
                </text>
              </g>
            ))}
            <g transform="translate(810 610)">
              <path
                d="M-47 -35L-34 62Q4 80 38 62L49 -35"
                fill="#528d0d"
                stroke="#91b443"
                strokeWidth="2"
              />
              <ellipse
                cy="-35"
                rx="48"
                ry="14"
                fill="#1b3107"
                stroke="#a4c951"
                strokeWidth="2"
              />
              <text x="90" y="22" fill="#fff" fontSize="32" fontWeight="700">
                S3
              </text>
              <path d="M45 9h34" stroke="#a3b79b" />
              <circle cx="47" cy="9" r="6" fill="#cdf3bd" />
            </g>
          </g>
        </svg>
        <div
          style={{
            position: "absolute",
            top: 10,
            left: 440,
            opacity: reveal,
            scale: `${tween(f, 25, 43, 0.2, 1)}`,
          }}
        >
          <Bolt size={150} />
        </div>
        <div
          style={{
            position: "absolute",
            top: 730,
            left: 0,
            right: 0,
            textAlign: "center",
            opacity: reveal,
          }}
        >
          <Bolt size={128} />
          <div
            style={{
              fontSize: 56,
              fontWeight: 700,
              color: "#f1f7f4",
              marginTop: 10,
            }}
          >
            supabase
          </div>
        </div>
      </div>
      <div
        style={{
          position: "absolute",
          top: 1300,
          left: 0,
          right: 0,
          textAlign: "center",
          fontFamily: mono,
          fontSize: 30,
          color: "#666c6a",
        }}
      >
        <span style={{ color: "#d8dddb", fontWeight: 700 }}>
          {count.toLocaleString("en-US")}
        </span>{" "}
        novos bancos de dados / semana
      </div>
    </AbsoluteFill>
  );
};
