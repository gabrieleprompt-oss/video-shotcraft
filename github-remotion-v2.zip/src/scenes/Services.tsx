import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import {
  ApiCard,
  AuthCard,
  BackendCode,
  MessagesTable,
  Sidebar,
} from "../components/Interfaces";
import { tween } from "../theme";
export const Services = () => {
  const f = useCurrentFrame();
  const smallTable = tween(f, 10, 22),
    smallAuth = tween(f, 39, 50);
  const gone = tween(f, 60, 66);
  return (
    <AbsoluteFill style={{ background: "#fafafa", opacity: tween(f, 0, 4) }}>
      <div style={{ opacity: 1 - gone }}>
        <Sidebar />
        <div
          style={{
            position: "absolute",
            top: 550 + smallTable * 510,
            left: 150,
            scale: `${1 - smallTable * 0.66}`,
            transformOrigin: "top left",
            filter: `blur(${(1 - tween(f, 0, 6)) * 7}px)`,
          }}
        >
          <MessagesTable />
        </div>
        <div
          style={{
            position: "absolute",
            top: 555 + smallAuth * 505,
            left: 140 + tween(f, 39, 50, 0, 327) + tween(f, 5, 15, 980, 0),
            scale: `${1 - smallAuth * 0.64}`,
            transformOrigin: "top left",
            opacity: tween(f, 5, 12),
          }}
        >
          <AuthCard frame={f - 11} />
        </div>
        <div
          style={{
            position: "absolute",
            top: 550,
            left: 140 + tween(f, 32, 42, 1000, 0),
            opacity: tween(f, 32, 39),
          }}
        >
          <ApiCard frame={f - 39} />
        </div>
      </div>
      <div
        style={{
          position: "absolute",
          left: 98,
          top: 565,
          opacity: tween(f, 60, 65),
        }}
      >
        <BackendCode frame={f - 61} />
      </div>
    </AbsoluteFill>
  );
};
