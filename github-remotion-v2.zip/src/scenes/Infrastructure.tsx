import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { FrontRack } from "../components/Hardware";
import { MiniCards } from "../components/Interfaces";
import { tween } from "../theme";
export const Infrastructure = () => {
  const f = useCurrentFrame();
  const sw = tween(f, 65, 78);
  return (
    <AbsoluteFill style={{ background: "#fafafa" }}>
      <div
        style={{
          position: "absolute",
          left: 40,
          top: 770 + tween(f, 0, 11, 140, 0),
          width: 1000,
          scale: `1 ${tween(f, 0, 9, 0.55, 1)}`,
          transformOrigin: "center bottom",
        }}
      >
        <FrontRack software={sw} />
      </div>
      <div
        style={{
          position: "absolute",
          top: 618 - sw * 62,
          left: 63,
          opacity: tween(f, 0, 6),
          translate: `0 ${tween(f, 0, 12, -40, 0)}px`,
        }}
      >
        <MiniCards />
      </div>
    </AbsoluteFill>
  );
};
