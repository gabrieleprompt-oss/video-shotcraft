import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { PerspectiveServer } from "../components/Hardware";
import { ProjectForm } from "./CreateProject";
import { tween } from "../theme";
export const Instance = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{ background: "#101110" }}>
      <div
        style={{
          position: "absolute",
          left: 25,
          top: 480,
          width: 1030,
          opacity: tween(f, 0, 8),
          scale: tween(f, 0, 10, 0.98, 1),
        }}
      >
        <PerspectiveServer frame={f} />
      </div>
      {f < 12 ? (
        <div
          style={{
            position: "absolute",
            left: 50,
            top: 562,
            opacity: 1 - tween(f, 0, 10),
            transform: `perspective(1400px) rotateX(${tween(f, 0, 11, 0, 59)}deg)`,
            transformOrigin: "center",
          }}
        >
          <ProjectForm frame={96} />
        </div>
      ) : null}
    </AbsoluteFill>
  );
};
