import React from "react";
import { Bolt } from "./Logos";
import { linear, mono } from "../theme";
import { palette } from "../style-lock";
export const ChapterBar = ({
  frame,
  light = false,
}: {
  frame: number;
  light?: boolean;
}) => (
  <div
    style={{
      position: "absolute",
      left: 48,
      right: 48,
      top: 466,
      height: 72,
      display: "flex",
      alignItems: "center",
      gap: 27,
      color: light ? palette.quiet : palette.muted,
      fontFamily: mono,
      fontSize: 10,
      opacity: linear(frame, 287, 300),
    }}
  >
    <Bolt size={37} />
    {[
      "SERVIDOR",
      "API",
      "SEGURANÇA",
      "STORAGE",
      "LIVE",
      "BACKUP",
      "FUNÇÕES",
      "AUTOMAÇÃO",
    ].map((x, i) => (
      <div
        key={x}
        style={{
          flex: 1,
          textAlign: "center",
          position: "relative",
          color: i === 0 ? palette.accent : undefined,
        }}
      >
        <div style={{ fontSize: 22, marginBottom: 8, opacity: 0.6 }}>
          {["▦", "⌁", "♧", "▤", "↔", "◫", "⋈", "◴"][i]}
        </div>
        <div
          style={{
            borderTop: `1px solid ${i === 0 ? palette.accentDark : "#393b39"}`,
            paddingTop: 5,
            letterSpacing: 0.2,
          }}
        >
          {x}
        </div>
        {i === 0 ? (
          <span
            style={{
              position: "absolute",
              width: 22,
              height: 6,
              background: palette.accent,
              left: 14,
              top: 28,
            }}
          />
        ) : null}
      </div>
    ))}
    <div style={{ marginLeft: 10, textAlign: "center" }}>
      <div style={{ fontSize: 21, color: light ? palette.text : palette.white }}>0</div>
      mensagens
    </div>
  </div>
);
