import React from "react";
import { Img, staticFile } from "remotion";
export const Bolt = ({
  size = 50,
  color,
  style,
}: {
  size?: number;
  color?: string;
  style?: React.CSSProperties;
}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" style={style}>
    <defs>
      <linearGradient id="boltFill" x1="0" x2="1" y1="0" y2="1">
        <stop stopColor="#57f29b" />
        <stop offset="1" stopColor="#1ab66e" />
      </linearGradient>
    </defs>
    <path
      fill={color ?? "url(#boltFill)"}
      d="M11.9 1.036c-.015-.986-1.26-1.41-1.874-.637L.764 12.05C-.33 13.427.65 15.455 2.409 15.455h9.579l.113 7.51c.014.985 1.259 1.408 1.873.636l9.262-11.653c1.093-1.375.113-3.403-1.645-3.403h-9.642z"
    />
  </svg>
);
export const PgLogo = ({ size = 80 }: { size?: number }) => (
  <Img
    src={staticFile("logos/postgresql.svg")}
    style={{
      width: size,
      height: size,
      filter:
        "invert(52%) sepia(25%) saturate(950%) hue-rotate(156deg) brightness(95%)",
    }}
  />
);
export const Aws = ({
  width = 150,
  dark = false,
}: {
  width?: number;
  dark?: boolean;
}) => (
  <svg width={width} height={width * 0.7} viewBox="0 0 150 105">
    <text
      x="4"
      y="67"
      fontSize="75"
      fontFamily="Arial"
      fill={dark ? "#1a2634" : "#f6f9ff"}
      letterSpacing="-4"
    >
      aws
    </text>
    <path
      d="M12 79 Q66 112 127 78"
      fill="none"
      stroke="#ffad21"
      strokeWidth="6"
      strokeLinecap="round"
    />
    <path
      d="M110 78 Q128 72 135 76 L130 93"
      fill="none"
      stroke="#ffad21"
      strokeWidth="5"
      strokeLinecap="round"
    />
  </svg>
);
export const EC2Icon = ({ size = 48 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 50 50">
    <rect width="50" height="50" rx="3" fill="#e98a20" />
    <rect
      x="11"
      y="11"
      width="28"
      height="28"
      fill="none"
      stroke="#fff"
      strokeWidth="2"
    />
    <rect x="17" y="17" width="16" height="16" fill="none" stroke="#ffe4b3" />
    {[15, 23, 31, 39].map((x) => (
      <path
        key={x}
        d={`M${x} 7v5 M${x} 39v5 M7 ${x}h5 M39 ${x}h5`}
        stroke="#fff"
      />
    ))}
  </svg>
);
