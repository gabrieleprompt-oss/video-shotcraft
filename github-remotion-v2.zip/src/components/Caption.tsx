import React from "react";
import { useCurrentFrame } from "remotion";
import { sans, tween } from "../theme";
import { motionSpec, palette, typography } from "../style-lock";
type Word = { text: string; at: number; selected?: boolean };
type Cue = { from: number; to: number; lines: Word[][]; size?: number };
export const captionCues: Cue[] = [
  {
    from: 0,
    to: 44,
    lines: [
      [
        { text: "Vamos", at: 0 },
        { text: "projetar", at: 8 },
      ],
      [
        { text: "o", at: 19 },
        { text: "Supabase.", at: 24, selected: true },
      ],
    ],
  },
  {
    from: 44,
    to: 73,
    lines: [
      [
        { text: "O Supabase", at: 0 },
        { text: "oferece", at: 12 },
      ],
    ],
  },
  {
    from: 73,
    to: 88,
    lines: [
      [
        { text: "um", at: 0 },
        { text: "banco de dados,", at: 1, selected: true },
      ],
    ],
    size: 72,
  },
  {
    from: 88,
    to: 133,
    lines: [
      [
        { text: "logins", at: 0, selected: true },
        { text: "e uma", at: 22 },
        { text: "API", at: 31 },
      ],
    ],
  },
  {
    from: 133,
    to: 168,
    lines: [
      [
        { text: "sem precisar", at: 0 },
        { text: "escrever", at: 9 },
      ],
      [
        { text: "um", at: 17 },
        { text: "backend.", at: 20, selected: true },
      ],
    ],
    size: 75,
  },
  {
    from: 168,
    to: 207,
    lines: [
      [{ text: "Por baixo,", at: 0 }],
      [
        { text: "é a", at: 12 },
        { text: "AWS,", at: 16, selected: true },
      ],
    ],
  },
  {
    from: 207,
    to: 269,
    lines: [
      [
        { text: "com o software", at: 0 },
        { text: "do próprio", at: 18 },
      ],
      [
        { text: "Supabase", at: 29, selected: true },
        { text: "por cima.", at: 43 },
      ],
    ],
    size: 70,
  },
  {
    from: 269,
    to: 309,
    lines: [
      [{ text: "Vamos criar", at: 0 }],
      [
        { text: "um app de", at: 8 },
        { text: "chat.", at: 16, selected: true },
      ],
    ],
  },
  {
    from: 313,
    to: 351,
    lines: [
      [
        { text: "Primeiro,", at: 0 },
        { text: "o", at: 11 },
      ],
      [{ text: "banco de dados.", at: 15, selected: true }],
    ],
  },
  {
    from: 351,
    to: 383,
    lines: [
      [
        { text: "Clique em", at: 0 },
        { text: "Novo projeto,", at: 8, selected: true },
      ],
    ],
    size: 72,
  },
  {
    from: 383,
    to: 404,
    lines: [
      [
        { text: "e o", at: 0 },
        { text: "Supabase", at: 4 },
        { text: "inicia", at: 12 },
      ],
    ],
    size: 76,
  },
  {
    from: 404,
    to: 440,
    lines: [
      [
        { text: "um servidor", at: 0, selected: true },
        { text: "inteiro", at: 8 },
      ],
      [{ text: "para você:", at: 20 }],
    ],
    size: 75,
  },
  {
    from: 440,
    to: 469,
    lines: [
      [
        { text: "uma instância", at: 0 },
        { text: "EC2,", at: 4, selected: true },
      ],
    ],
    size: 76,
  },
  {
    from: 469,
    to: 519,
    lines: [
      [{ text: "um computador", at: 0 }],
      [
        { text: "que a Amazon", at: 19 },
        { text: "aluga.", at: 31, selected: true },
      ],
    ],
    size: 74,
  },
  {
    from: 519,
    to: 566,
    lines: [
      [
        { text: "Nele roda o", at: 0 },
        { text: "Postgres.", at: 14, selected: true },
      ],
    ],
    size: 76,
  },
];
export const Caption = ({ light = false }: { light?: boolean }) => {
  const frame = useCurrentFrame();
  const cue = captionCues.find((c) => frame >= c.from && frame < c.to);
  if (!cue) return null;
  const f = frame - cue.from;
  return (
    <div
      style={{
        position: "absolute",
        left: 45,
        right: 45,
        top: typography.caption.top,
        textAlign: "center",
        fontFamily: sans,
        fontSize: cue.size ?? typography.caption.size,
        lineHeight: typography.caption.lineHeight,
        letterSpacing: typography.caption.letterSpacing,
        zIndex: 20,
        color: light ? palette.ink : palette.white,
      }}
    >
      {cue.lines.map((line, i) => (
        <div key={i} style={{ minHeight: "1.11em", whiteSpace: "nowrap" }}>
          {line.map((w, j) => {
            const visible = f >= w.at;
            const next = line[j + 1];
            const current = visible && (!next || f < next.at);
            return (
              <React.Fragment key={j}>
                {j > 0 && visible ? " " : null}
                <span
                  style={{
                    display: visible ? "inline-block" : "none",
                    position: "relative",
                    fontWeight: current || w.selected ? 700 : 400,
                    color:
                      current || w.selected
                        ? light
                          ? palette.ink
                          : palette.white
                        : light
                          ? palette.quiet
                          : palette.muted,
                    filter:
                      visible && f - w.at < motionSpec.microBlurFrames
                        ? `blur(${(1 - tween(f, w.at, w.at + motionSpec.microBlurFrames)) * 5}px)`
                        : "none",
                  }}
                >
                  {w.text}
                  {w.selected && visible ? (
                    <span
                      style={{
                        position: "absolute",
                        inset: "-1px -5px -1px",
                        border: "2px solid #397bc1",
                        background: "rgba(69,133,216,0.09)",
                        opacity: tween(
                          f,
                          w.at + 1,
                          w.at + 1 + motionSpec.captionWordFrames,
                        ),
                      }}
                    >
                      <i
                        style={{
                          position: "absolute",
                          width: 12,
                          height: 12,
                          background: "#4285d0",
                          border: "2px solid #d7e6f6",
                          borderRadius: "50%",
                          left: -8,
                          top: -8,
                        }}
                      />
                      <i
                        style={{
                          position: "absolute",
                          width: 12,
                          height: 12,
                          background: "#4285d0",
                          border: "2px solid #d7e6f6",
                          borderRadius: "50%",
                          right: -8,
                          bottom: -8,
                        }}
                      />
                    </span>
                  ) : null}
                </span>
              </React.Fragment>
            );
          })}
        </div>
      ))}
    </div>
  );
};
