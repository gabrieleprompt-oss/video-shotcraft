import React from "react";
import { useCurrentFrame } from "remotion";
import { palette, typography } from "../style-lock";
import { sans, tween } from "../theme";

export type ScriptCue = {
  from: number;
  to: number;
  text: string;
  emphasis?: string;
};

export const ScriptCaption = ({
  cues,
  dark = false,
}: {
  cues: readonly ScriptCue[];
  dark?: boolean;
}) => {
  const frame = useCurrentFrame();
  const cue = cues.find((item) => frame >= item.from && frame < item.to);
  if (!cue) return null;
  const shown = cue.emphasis ? cue.text.split(cue.emphasis) : [cue.text];
  return (
    <div
      style={{
        position: "absolute",
        left: 48,
        right: 48,
        top: typography.caption.top,
        textAlign: "center",
        fontFamily: sans,
        fontSize: cue.text.length > 42 ? 64 : typography.caption.size,
        lineHeight: typography.caption.lineHeight,
        letterSpacing: typography.caption.letterSpacing,
        fontWeight: 700,
        color: dark ? palette.white : palette.ink,
        zIndex: 20,
        opacity: tween(frame, cue.from, cue.from + 4),
        transform: `translateY(${tween(frame, cue.from, cue.from + 4, 18, 0)}px)`,
      }}
    >
      {cue.emphasis ? (
        <>
          {shown[0]}
          <span
            style={{
              color: dark ? palette.accent : palette.accentDark,
              position: "relative",
            }}
          >
            {cue.emphasis}
            <span
              style={{
                position: "absolute",
                left: -7,
                right: -7,
                bottom: -5,
                height: 5,
                background: dark ? palette.accent : palette.accentDark,
                borderRadius: 3,
                transform: `scaleX(${tween(frame, cue.from + 4, cue.from + 9)})`,
                transformOrigin: "left",
              }}
            />
          </span>
          {shown[1]}
        </>
      ) : (
        cue.text
      )}
    </div>
  );
};
