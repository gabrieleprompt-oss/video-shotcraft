import React from "react";
import { staticFile } from "remotion";
import { linear, tween } from "../theme";

const Screw = ({ x, y }: { x: number; y: number }) => (
  <g transform={`translate(${x} ${y})`}>
    <circle r="6" fill="#0d1218" stroke="#4b525a" strokeWidth="2" />
    <path d="M-3 -2L3 2M-3 2L3 -2" stroke="#737a82" strokeWidth="1.5" />
  </g>
);
export const Fan = ({ x, y, r = 37 }: { x: number; y: number; r?: number }) => (
  <g transform={`translate(${x} ${y})`}>
    <rect
      x={-r - 6}
      y={-r - 6}
      width={2 * r + 12}
      height={2 * r + 12}
      rx="4"
      fill="#080e17"
      stroke="#3e4650"
      strokeWidth="2"
    />
    {[0, 45, 90, 135, 180, 225, 270, 315].map((a) => (
      <path
        key={a}
        transform={`rotate(${a})`}
        d={`M0 -5 Q${r * 0.7} ${-r * 0.6} ${r * 0.68} ${-r * 0.1} Q${r * 0.4} ${r * 0.2} 5 3Z`}
        fill="#333b46"
      />
    ))}
    {[r * 0.4, r * 0.72, r].map((v) => (
      <circle
        key={v}
        r={v}
        fill="none"
        stroke="#62707b"
        strokeOpacity=".35"
        strokeWidth="1"
      />
    ))}
    <circle r="9" fill="#141d27" stroke="#555d66" />
    {[-1, 1].flatMap((i) =>
      [-1, 1].map((j) => (
        <Screw key={`${i}${j}`} x={i * (r + 1)} y={j * (r + 1)} />
      )),
    )}
  </g>
);
const Led = ({
  x,
  y,
  color = "#65d6a6",
}: {
  x: number;
  y: number;
  color?: string;
}) => (
  <g>
    <circle cx={x} cy={y} r="9" fill={color} opacity=".09" />
    <circle cx={x} cy={y} r="4" fill={color} />
    <circle cx={x - 1} cy={y - 1} r="1.5" fill="#d1fff0" />
  </g>
);
const AwsSvg = ({
  x,
  y,
  scale = 1,
}: {
  x: number;
  y: number;
  scale?: number;
}) => (
  <g transform={`translate(${x} ${y}) scale(${scale})`}>
    <text
      x="0"
      y="70"
      fill="#fafafa"
      fontSize="86"
      fontFamily="Arial"
      letterSpacing="-4"
    >
      aws
    </text>
    <path
      d="M3 88 Q67 124 141 82"
      fill="none"
      stroke="#ffad2a"
      strokeWidth="6"
      strokeLinecap="round"
    />
    <path
      d="M124 83 Q141 76 150 81 L143 101"
      fill="none"
      stroke="#ffad2a"
      strokeWidth="5"
    />
  </g>
);
const ChipIcon = ({
  x,
  y,
  size = 55,
}: {
  x: number;
  y: number;
  size?: number;
}) => (
  <g transform={`translate(${x} ${y}) scale(${size / 50})`}>
    <rect width="50" height="50" rx="3" fill="#e68b22" />
    <path
      d="M12 12h26v26H12zM18 18h14v14H18z"
      fill="none"
      stroke="#ffe2b4"
      strokeWidth="1.8"
    />
    {[15, 23, 31, 39].map((n) => (
      <path
        key={n}
        d={`M${n} 7v6 M${n} 38v6 M7 ${n}h6 M38 ${n}h6`}
        stroke="#fff0d2"
      />
    ))}
  </g>
);

export const FrontRack = ({ software = 0 }: { software?: number }) => (
  <svg viewBox="0 0 1000 380" width="100%" style={{ overflow: "visible" }}>
    <defs>
      <linearGradient id="frontMetal" x2="0" y2="1">
        <stop stopColor="#344254" />
        <stop offset=".4" stopColor="#263244" />
        <stop offset="1" stopColor="#151e2a" />
      </linearGradient>
      <linearGradient id="greenSlab" x2="0" y2="1">
        <stop stopColor="#43e99b" />
        <stop offset="1" stopColor="#24bd76" />
      </linearGradient>
    </defs>
    <ellipse cx="500" cy="330" rx="458" ry="30" fill="#000" opacity=".12" />
    <path
      d="M20 84L45 27H955L980 84Z"
      fill="#263243"
      stroke="#46515f"
      strokeWidth="2"
    />
    {Array.from({ length: 65 }, (_, i) => (
      <path
        key={i}
        d={`M${58 + i * 13.5} 48l-3 10`}
        stroke="#101926"
        strokeWidth="4"
      />
    ))}
    <rect
      x="20"
      y="84"
      width="960"
      height="234"
      rx="7"
      fill="url(#frontMetal)"
      stroke="#566072"
      strokeWidth="3"
    />
    <path d="M33 93H965M33 305H967" stroke="#6d7e8a" opacity=".25" />
    <AwsSvg x={83} y={105} scale={1.1} />
    <ChipIcon x={89} y={244} size={39} />
    <text x="143" y="274" fontSize="30" fill="#fff" fontWeight="700">
      Amazon EC2
    </text>
    {Array.from({ length: 8 }, (_, i) => {
      const x = 428 + (i % 4) * 81,
        y = 120 + Math.floor(i / 4) * 92;
      return (
        <g key={i}>
          <rect
            x={x}
            y={y}
            width="70"
            height="83"
            rx="4"
            fill="#101c2b"
            stroke="#526074"
          />
          {Array.from({ length: 9 }, (_, n) => (
            <path
              key={n}
              d={`M${x + 6} ${y + 26 + n * 5}h57`}
              stroke="#425263"
              strokeWidth="1"
            />
          ))}
          <path d={`M${x + 9} ${y + 10}h30`} stroke="#2d3947" strokeWidth="4" />
          <Led x={x + 8} y={y + 8} />
        </g>
      );
    })}
    {[790, 886].flatMap((x) =>
      [155, 253].map((y) => <Fan key={`${x}${y}`} x={x} y={y} r={36} />),
    )}
    {[42, 958].flatMap((x) =>
      [111, 289].map((y) => <Screw key={`${x}${y}`} x={x} y={y} />),
    )}
    <g opacity={software} transform={`translate(0 ${-52 * software})`}>
      <path d="M40 74L47 42H953L960 74Z" fill="#67efa9" />
      <path d="M40 74H960V137H40Z" fill="url(#greenSlab)" stroke="#81ffbe" />
      <image
        href={staticFile("logos/supabase.svg")}
        x="393"
        y="83"
        width="35"
        height="35"
      />
      <text x="440" y="111" fontSize="33" fill="#082a1a" fontWeight="700">
        supabase
      </text>
    </g>
  </svg>
);

export const PerspectiveServer = ({
  frame,
  opening = 0,
}: {
  frame: number;
  opening?: number;
}) => {
  const price = linear(frame, 75, 97, 0, 0.01344).toFixed(5);
  return (
    <svg viewBox="0 0 1000 760" width="100%" style={{ overflow: "visible" }}>
      <defs>
        <linearGradient id="lidMetal" x1="0" y1="0" x2="1" y2="1">
          <stop stopColor="#43474f" />
          <stop offset=".42" stopColor="#30333a" />
          <stop offset="1" stopColor="#1d222a" />
        </linearGradient>
        <linearGradient id="serverFront" x2="0" y2="1">
          <stop stopColor="#373b43" />
          <stop offset=".6" stopColor="#111820" />
          <stop offset="1" stopColor="#2d3238" />
        </linearGradient>
        <linearGradient id="board" x2="1" y2="1">
          <stop stopColor="#081b18" />
          <stop offset="1" stopColor="#164535" />
        </linearGradient>
        <pattern id="vent" width="8" height="7" patternUnits="userSpaceOnUse">
          <path d="M1 2h5M1 4h5" stroke="#65737c" strokeOpacity=".35" />
        </pattern>
      </defs>
      <ellipse cx="500" cy="572" rx="446" ry="39" fill="#000" opacity=".7" />
      <path
        d="M142 78H858L969 473L949 580H51L31 473Z"
        fill="#141b20"
        stroke="#555b61"
        strokeWidth="4"
      />
      <path
        d="M157 95H845L939 467H61Z"
        fill="url(#board)"
        stroke="#454e51"
        strokeWidth="3"
      />
      {Array.from({ length: 19 }, (_, i) => (
        <path
          key={i}
          d={`M${185 + i * 33} 120V${200 + (i % 6) * 35}L${130 + i * 39} ${405 - (i % 4) * 10}`}
          fill="none"
          stroke={i % 2 ? "#28694a" : "#4a8666"}
          strokeWidth="2"
          opacity=".45"
        />
      ))}
      {[0, 1, 2, 3].map((i) => (
        <g key={i} transform={`translate(${143 - i * 17} ${183 + i * 62})`}>
          <path d="M0 0H255L263 37H-8Z" fill="#0b1213" stroke="#5c6556" />
          {Array.from({ length: 40 }, (_, n) => (
            <path
              key={n}
              d={`M${n * 6.2 + 4} 4v28`}
              stroke="#8c9a7b"
              strokeWidth="1.5"
            />
          ))}
          <path d="M10 35h243" stroke="#b4ab75" strokeWidth="3" />
        </g>
      ))}
      <g transform="translate(555 188)">
        <rect
          x="-22"
          y="-18"
          width="264"
          height="198"
          fill="#1e3031"
          stroke="#5b6b67"
          strokeWidth="8"
        />
        <rect
          width="222"
          height="153"
          fill="#28333c"
          stroke="#87958a"
          strokeWidth="4"
        />
        <path d="M9 10H213" stroke="#667a7d" strokeWidth="3" />
        <image
          href={staticFile("logos/postgresql.svg")}
          x="65"
          y="20"
          width="90"
          height="90"
          style={{
            filter: "invert(65%) sepia(27%) saturate(751%) hue-rotate(165deg)",
          }}
        />
        <text
          x="112"
          y="137"
          fill="#fff"
          textAnchor="middle"
          fontSize="29"
          fontWeight="700"
        >
          PostgreSQL
        </text>
      </g>
      <g transform="translate(500 410)">
        <path
          d="M0 0H337L350 50H-8Z"
          fill="#3b4345"
          stroke="#657075"
          strokeWidth="3"
        />
        <text
          x="57"
          y="34"
          fill="#fff"
          fontSize="29"
          fontFamily="ReferenceMono"
        >
          gp3 · 8 GB
        </text>
        <rect x="5" y="10" width="8" height="27" fill="#b09d49" />
        <Led x={317} y={24} />
      </g>
      {[0, 1, 2, 3].map((i) => (
        <Fan key={i} x={230 + i * 159} y={135} r={29} />
      ))}
      <g
        opacity={1 - tween(opening, 0.75, 1)}
        transform={`translate(0 ${-opening * 510})`}
      >
        <path
          d="M142 78H858L969 473H31Z"
          fill="url(#lidMetal)"
          stroke="#555b61"
          strokeWidth="5"
        />
        <path
          d="M163 93H840L845 132H156Z"
          fill="#20252b"
          stroke="#555a63"
          strokeWidth="2"
        />
        <path d="M159 137H846" stroke="#191d23" strokeWidth="5" />
        <path
          d="M60 458L162 103M938 458L840 103"
          stroke="#646b73"
          strokeOpacity=".28"
          strokeWidth="8"
        />
        <path
          d="M440 421H573L578 439H435Z"
          fill="#12151b"
          stroke="#5b6269"
          strokeWidth="3"
        />
        <g transform="translate(246 264) skewX(-8)">
          <rect x="-2" y="4" width="533" height="98" rx="5" fill="#0d141a" />
          <rect width="526" height="92" rx="4" fill="#ebeeec" />
          <image
            href={staticFile("logos/supabase.svg")}
            x="27"
            y="15"
            width="40"
            height="27"
            style={{
              filter: "invert(61%) sepia(70%) saturate(373%) hue-rotate(92deg)",
            }}
          />
          <text x="80" y="40" fontSize="42" fontWeight="700" fill="#101513">
            chatty
          </text>
          <text
            x="288"
            y="39"
            fontSize="20"
            fontWeight="700"
            fill="#388b6d"
            opacity={tween(frame, 25, 44)}
          >
            ● Em execução
          </text>
          <text
            x="30"
            y="73"
            fill="#303b37"
            fontSize="24"
            fontFamily="ReferenceMono"
          >
            qzvhkmtplxrwbdfyecs
          </text>
        </g>
        {[170, 829].flatMap((x) =>
          [157, 409].map((y) => (
            <Screw
              key={`${x}${y}`}
              x={x + (x < 500 ? -(y - 157) * 0.28 : (y - 157) * 0.28)}
              y={y}
            />
          )),
        )}
      </g>
      <path
        d="M31 473H969L949 580H51Z"
        fill="url(#serverFront)"
        stroke="#464d55"
        strokeWidth="3"
      />
      <ChipIcon x={75} y={495} size={60} />
      <AwsSvg x={154} y={492} scale={0.56} />
      <text
        x="265"
        y="543"
        fontSize="30"
        fill="#fff"
        fontFamily="ReferenceMono"
      >
        eu-central-1
      </text>
      <Fan x={625} y={526} r={35} />
      <Fan x={719} y={526} r={35} />
      <circle
        cx="821"
        cy="511"
        r="14"
        stroke="#58b493"
        strokeWidth="4"
        fill="none"
      />
      <Led x={864} y={511} color="#efba4d" />
      <Led x={892} y={511} />
      <rect x="790" y="537" width="128" height="30" fill="url(#vent)" />
      {[54, 944].flatMap((x) =>
        [491, 559].map((y) => <Screw key={`${x}${y}`} x={x} y={y} />),
      )}
      <g
        opacity={tween(frame, 70, 79) * (1 - tween(opening, 0, 0.45))}
        transform={`translate(${590 + tween(frame, 70, 82, 80, 0)} ${610 + tween(frame, 70, 82, 60, 0)}) rotate(-5)`}
      >
        <path
          d="M-8 -38Q170 -70 270 -90"
          stroke="#565250"
          strokeWidth="3"
          fill="none"
        />
        <rect x="-40" y="-20" width="409" height="123" rx="7" fill="#edeae0" />
        <circle cx="163" cy="-6" r="6" fill="#282b27" />
        <text x="100" y="21" fontSize="25" fill="#20251f">
          Micro · 1 GB
        </text>
        <text
          x="83"
          y="67"
          fontSize="34"
          fontFamily="ReferenceMono"
          fill="#131812"
          fontWeight="700"
        >
          ${price}
          <tspan fontSize="23"> / hora</tspan>
        </text>
        <text x="-20" y="44" fontSize="25" fill="#20251f">
          aws
        </text>
        <path
          d="M-18 51q26 17 55 -1"
          fill="none"
          stroke="#d39e32"
          strokeWidth="3"
        />
      </g>
    </svg>
  );
};
