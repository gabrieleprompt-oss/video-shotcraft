import React from "react";
import { Bolt } from "./Logos";
import { green, linear, mono, sans, tween } from "../theme";
import { palette, surfaces } from "../style-lock";
import { referenceCardStyle } from "./ReferenceSurface";
const card: React.CSSProperties = { ...referenceCardStyle };
export const MessagesTable = ({
  compact = false,
  updated = false,
}: {
  compact?: boolean;
  updated?: boolean;
}) => (
  <div
    style={{ ...card, width: compact ? 310 : 900, height: compact ? 185 : 400 }}
  >
    <div
      style={{
        background: "#f5f5f4",
        padding: compact ? "9px 13px" : "20px 25px",
        fontSize: compact ? 25 : 40,
        fontWeight: 700,
      }}
    >
      messages
    </div>
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "20% 35% 45%",
        fontFamily: sans,
        fontSize: compact ? 20 : 33,
      }}
    >
      {["id", "room_id", "body"].map((x) => (
        <div
          key={x}
          style={{
            background: "#f2f3f2",
            padding: compact ? 5 : 14,
            fontWeight: 700,
            borderRight: "1px solid #d7dad7",
          }}
        >
          {x}
        </div>
      ))}
      {Array.from({ length: 9 }, (_, i) => (
        <div
          key={i}
          style={{
            height: compact ? 34 : 66,
            borderRight: "1px solid #dfe2df",
            borderBottom: "1px solid #dfe2df",
            padding: 5,
            background: updated && i === 2 ? "#dbf7e7" : undefined,
          }}
        >
          {updated && i < 3 ? ["1", "1", "Olá!"][i] : ""}
        </div>
      ))}
    </div>
  </div>
);
export const AuthCard = ({
  frame = 0,
  compact = false,
}: {
  frame?: number;
  compact?: boolean;
}) => {
  const w = compact ? 310 : 860;
  const size = compact ? 19 : 28;
  return (
    <div style={{ ...card, width: w, minHeight: compact ? 185 : 510 }}>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          padding: compact ? "9px 12px" : "22px 28px",
          background: "#f7f8f7",
          fontSize: compact ? 24 : 36,
          fontWeight: 700,
        }}
      >
        Autenticação
        {!compact ? (
          <span style={{ fontSize: 20, color: "#666", alignSelf: "center" }}>
            Entrar / Provedores
          </span>
        ) : null}
      </div>
      <div
        style={{ padding: compact ? "6px 12px" : "23px 75px", fontSize: size }}
      >
        {!compact ? (
          <div style={{ fontSize: 23, color: "#7b7e7b", marginBottom: 10 }}>
            Endereço de e-mail
          </div>
        ) : null}
        <div
          style={{
            height: compact ? 43 : 57,
            border: `1px solid ${frame < 23 ? "#50c18a" : "#c8ceca"}`,
            boxShadow: frame < 23 ? "0 0 6px #2bc57d35" : undefined,
            padding: compact ? 6 : 10,
            overflow: "hidden",
            whiteSpace: "nowrap",
          }}
        >
          {compact
            ? "mei@example.com"
            : "mei@example.com".slice(
                0,
                Math.floor(linear(frame, 0, 18, 0, 15)),
              )}
        </div>
        {!compact ? (
          <>
            <div
              style={{ fontSize: 23, color: "#7b7e7b", margin: "16px 0 9px" }}
            >
              Senha
            </div>
            <div
              style={{ height: 55, border: "1px solid #d7ddd8", padding: 10 }}
            >
              {"•".repeat(Math.floor(linear(frame, 20, 29, 0, 8)))}
            </div>
          </>
        ) : null}
        <div
          style={{
            marginTop: compact ? 7 : 24,
            height: compact ? 39 : 63,
            background: green,
            color: "#fff",
            textAlign: "center",
            paddingTop: compact ? 6 : 12,
            fontSize: compact ? 23 : 30,
            boxShadow: "inset 0 1px 0 #ffffff40",
          }}
        >
          Entrar
        </div>
        {!compact ? (
          <div
            style={{
              fontSize: 20,
              textAlign: "center",
              marginTop: 22,
              color: "#676b67",
            }}
          >
            Não tem uma conta? <b style={{ color: "#151a15" }}>Cadastre-se</b>
          </div>
        ) : null}
      </div>
    </div>
  );
};
export const ApiCard = ({
  compact = false,
  frame = 0,
}: {
  compact?: boolean;
  frame?: number;
}) => (
  <div
    style={{ ...card, width: compact ? 310 : 900, height: compact ? 185 : 515 }}
  >
    <div
      style={{
        padding: compact ? "9px 12px" : "21px 28px",
        fontSize: compact ? 23 : 36,
        fontWeight: 700,
        background: "#f8f8f7",
        display: "flex",
        justifyContent: "space-between",
      }}
    >
      Documentação da API
      {!compact ? <span style={{ fontSize: 21 }}>JavaScript Bash</span> : null}
    </div>
    <div style={{ padding: compact ? "10px 12px" : "23px 30px" }}>
      <div
        style={{ color: "#777", fontSize: compact ? 19 : 25, marginBottom: 9 }}
      >
        URL do projeto
      </div>
      <div
        style={{
          background: "#fafbfa",
          fontFamily: mono,
          fontWeight: 700,
          fontSize: compact ? 35 : 24,
          border: "1px solid #edf0ed",
          padding: compact ? "2px 7px" : "10px 14px",
          whiteSpace: "nowrap",
        }}
      >
        {compact ? "/rest/v1/" : "https://qzvhkmtplxrwbdfyecs.supabase.co"}
      </div>
      {!compact ? (
        <>
          <div style={{ color: "#777", fontSize: 24, margin: "22px 0 8px" }}>
            Ler todas as linhas
          </div>
          <pre
            style={{
              background: "#1a1c1a",
              color: "#d3ded7",
              borderRadius: 7,
              fontFamily: mono,
              fontSize: 25,
              padding: 25,
              height: 190,
              margin: 0,
              overflow: "hidden",
            }}
          >
            {"let { data: messages } = await supabase\n  .from('messages')\n  .select('*')".slice(
              0,
              Math.floor(linear(frame, 0, 22, 8, 91)),
            )}
          </pre>
        </>
      ) : null}
    </div>
  </div>
);
export const MiniCards = () => (
  <div style={{ display: "flex", alignItems: "flex-end", gap: 12, width: 954 }}>
    <MessagesTable compact />
    <AuthCard compact />
    <ApiCard compact />
  </div>
);
export const Sidebar = () => (
  <div
    style={{
      position: "absolute",
      top: 535,
      left: 38,
      height: 692,
      width: 74,
      background: "#fff",
      borderRadius: 23,
      boxShadow: "0 14px 22px #0001",
      display: "flex",
      alignItems: "center",
      flexDirection: "column",
      paddingTop: 18,
      gap: 19,
      color: "#585e59",
    }}
  >
    <Bolt size={42} />
    <div style={{ height: 1, width: 46, background: "#ddd" }} />
    {["⌂", "▦", "⊡", "▤", "♧", "▱", "◎", "✣", "⌁", "☷", "▧", "⚙"].map(
      (x, i) => (
        <div
          key={i}
          style={{
            fontSize: 29,
            width: 44,
            textAlign: "center",
            borderRadius: 5,
            background: i === 1 ? "#eff0ef" : undefined,
          }}
        >
          {x}
        </div>
      ),
    )}
  </div>
);
export const BackendCode = ({ frame }: { frame: number }) => {
  const lines = [
    "res.json(rows);",
    "});",
    "",
    "app.post('/rooms/:id/messages', auth, async (req, res) => {",
    "  const msg = await insertMessage(req.user.sub, req.body);",
    "  broadcast(msg);",
    "  res.status(201).json(msg);",
    "});",
    "",
    "const wss = new WebSocketServer({ server });",
    "wss.on('connection', (socket, req) => {",
    "  socket.on('message', (raw) => {",
    "    const { room } = JSON.parse(raw);",
    "    subscribe(socket, room);",
    "  });",
    "});",
  ];
  return (
    <div
      style={{
        ...card,
        width: 900,
        height: 590,
        position: "relative",
        transform: `perspective(1600px) rotateX(${tween(frame, 20, 30, 0, 72)}deg)`,
        opacity: 1 - tween(frame, 22, 32),
      }}
    >
      <div
        style={{
          background: "#f0f0ed",
          padding: "18px 25px",
          fontFamily: mono,
          fontSize: 36,
          fontWeight: 700,
          display: "flex",
          justifyContent: "space-between",
        }}
      >
        <span>▧ server.js</span>
        <span>
          {Math.round(linear(frame, 0, 12, 291, 314))}{" "}
          <span style={{ fontWeight: 400 }}>linhas</span>
        </span>
      </div>
      <div
        style={{
          fontFamily: mono,
          fontSize: 24,
          padding: "10px 18px",
          lineHeight: 1.35,
          whiteSpace: "nowrap",
        }}
      >
        {lines.map((s, i) => (
          <div key={i}>
            <span
              style={{ color: "#969a95", display: "inline-block", width: 78 }}
            >
              {302 + i}
            </span>
            {s}
          </div>
        ))}
      </div>
      <div
        style={{
          position: "absolute",
          height: 14,
          background: "#777873",
          left: -20,
          top: 265,
          width: 960,
          rotate: "-3deg",
          borderRadius: 9,
          scale: `${tween(frame, 9, 15)} 1`,
          transformOrigin: "left",
        }}
      />
    </div>
  );
};
export const Phone = ({ frame }: { frame: number }) => (
  <div
    style={{
      width: 342,
      height: 619,
      border: surfaces.phone.border,
      borderRadius: surfaces.phone.radius,
      background: "#fff",
      boxShadow: surfaces.phone.shadow,
      overflow: "hidden",
      position: "relative",
      fontFamily: sans,
      color: palette.text,
    }}
  >
    <div
      style={{
        height: 37,
        display: "flex",
        padding: "10px 25px 0",
        justifyContent: "space-between",
        fontSize: 12,
        fontWeight: 700,
      }}
    >
      9:41
      <span
        style={{
          width: 96,
          height: 24,
          background: "#101410",
          borderRadius: 17,
          marginTop: -4,
        }}
      />
      ◂ ▰
    </div>
    <div
      style={{
        display: "flex",
        alignItems: "center",
        padding: "14px 15px",
        borderBottom: "1px solid #e7e8e5",
        gap: 8,
      }}
    >
      <span style={{ color: "#4d8474", fontSize: 25 }}>‹</span>
      <div style={{ display: "flex" }}>
        {["#786d52", "#826c56", "#776e6b"].map((c, i) => (
          <div
            key={c}
            style={{
              width: 30,
              height: 30,
              border: "1px solid #fff",
              borderRadius: "50%",
              marginLeft: i ? -10 : 0,
              background: c,
            }}
          />
        ))}
      </div>
      <div style={{ fontSize: 17, fontWeight: 700 }}>
        Viagem de fim de semana
        <div style={{ fontWeight: 400, color: "#919991", fontSize: 11 }}>
          3 participantes
        </div>
      </div>
    </div>
    <div style={{ padding: 19, opacity: tween(frame, 5, 15) }}>
      <div style={{ display: "flex", gap: 6 }}>
        {["#92967d", "#8b6856", "#4b6a61"].map((c) => (
          <div
            key={c}
            style={{
              width: 28,
              height: 28,
              background: c,
              borderRadius: "50%",
            }}
          />
        ))}
      </div>
      <div style={{ fontSize: 16, fontWeight: 700, marginTop: 12 }}>
        Viagem de fim de semana
      </div>
      <div style={{ fontSize: 13, color: "#9c9f99", marginTop: 4 }}>
        Organize os planos por aqui.
      </div>
    </div>
    <div
      style={{
        position: "absolute",
        left: 20,
        right: 20,
        bottom: 80,
        opacity: tween(frame, 16, 25),
      }}
    >
      <div
        style={{
          background: "#eef0ec",
          borderRadius: "14px 14px 14px 2px",
          fontSize: 15,
          padding: 12,
          width: 229,
        }}
      >
        Pessoal, vamos no sábado?
      </div>
      <div
        style={{
          background: "#c9f2df",
          borderRadius: "14px 14px 2px 14px",
          fontSize: 15,
          padding: 12,
          width: 145,
          margin: "12px 0 0 auto",
        }}
      >
        Combinado! 🙌
      </div>
    </div>
    <div
      style={{
        position: "absolute",
        bottom: 26,
        left: 15,
        right: 15,
        height: 37,
        borderRadius: 20,
        border: "1px solid #e3e4e1",
        fontSize: 13,
        padding: "10px 13px",
        color: "#a1a59d",
      }}
    >
      Mensagem <span style={{ float: "right", color: "#45a583" }}>↑</span>
    </div>
    <div
      style={{
        position: "absolute",
        bottom: 7,
        left: 115,
        width: 100,
        height: 5,
        background: "#222",
        borderRadius: 3,
      }}
    />
  </div>
);
