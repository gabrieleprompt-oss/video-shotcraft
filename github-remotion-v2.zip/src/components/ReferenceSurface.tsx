import React from "react";
import { palette, surfaces, typography } from "../style-lock";

export const referenceCardStyle: React.CSSProperties = {
  background: surfaces.card.background,
  borderRadius: surfaces.card.radius,
  boxShadow: surfaces.card.shadow,
  color: palette.text,
  fontFamily: typography.sansFamily,
  overflow: "hidden",
  border: surfaces.card.border,
};

export const ReferenceCard = ({
  children,
  width,
  height,
  style,
}: {
  children: React.ReactNode;
  width: number;
  height: number;
  style?: React.CSSProperties;
}) => (
  <div style={{ ...referenceCardStyle, width, height, ...style }}>{children}</div>
);

export const ReferenceBackground = ({
  dark = false,
  children,
}: {
  dark?: boolean;
  children: React.ReactNode;
}) => (
  <div
    style={{
      position: "absolute",
      inset: 0,
      background: dark ? palette.ink : palette.paper,
      color: dark ? palette.white : palette.text,
      fontFamily: typography.sansFamily,
    }}
  >
    {children}
  </div>
);
