import { referenceEpisode, type EpisodeSpec, type SceneId } from "./production";

export type EpisodeInput = {
  id: string;
  locale?: string;
  scenes: Array<{
    id: SceneId;
    label: string;
    durationInFrames: number;
  }>;
};

/**
 * Builds a new episode manifest while preserving the locked visual contract.
 * Scene components consume this manifest; content authors only provide the
 * narrative labels and measured durations.
 */
export const createEpisode = (input: EpisodeInput): EpisodeSpec => {
  let cursor = 0;
  const scenes = input.scenes.map((scene) => {
    const next = {
      ...scene,
      from: cursor,
      toExclusive: cursor + scene.durationInFrames,
    };
    cursor = next.toExclusive;
    return next;
  });
  return {
    ...referenceEpisode,
    id: input.id,
    locale: input.locale ?? referenceEpisode.locale,
    scenes,
  };
};

/** A copyable starting point for the next episode in the same channel. */
export const episodeTemplate = createEpisode({
  id: "episode-template",
  locale: "pt-BR",
  scenes: referenceEpisode.scenes.map(({ id, label, durationInFrames }) => ({
    id,
    label,
    durationInFrames,
  })),
});
