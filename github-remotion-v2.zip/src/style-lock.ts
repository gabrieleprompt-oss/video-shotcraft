/**
 * The visual contract for the Supabase reference format.
 *
 * Keep these values stable between episodes. A new episode may change its
 * content, but it should not silently change the visual language.
 */
export const referenceFormat = {
  width: 1080,
  height: 1920,
  fps: 30,
  aspectRatio: "9:16",
  safe: {
    left: 48,
    right: 48,
    top: 72,
    bottom: 86,
  },
} as const;

export const palette = {
  ink: "#101110",
  paper: "#fafafa",
  white: "#f6f7f6",
  text: "#151918",
  muted: "#626664",
  quiet: "#898b89",
  rule: "#dfe2df",
  accent: "#35d78b",
  accentDark: "#238d62",
  selection: "#397bc1",
  selectionFill: "rgba(69,133,216,0.09)",
  metalDeep: "#151e2a",
  metal: "#263244",
  code: "#1a1c1a",
} as const;

export const typography = {
  sansFamily: "ReferenceSans, Arial, sans-serif",
  monoFamily: "ReferenceMono, monospace",
  caption: {
    top: 174,
    size: 80,
    lineHeight: 1.1,
    letterSpacing: -2.4,
  },
  monoLabel: {
    size: 10,
    letterSpacing: 0.2,
  },
} as const;

export const surfaces = {
  card: {
    background: "#ffffff",
    border: "1px solid #edf0ed",
    radius: 8,
    shadow: "0 13px 26px #0002, 0 1px 3px #0001",
  },
  phone: {
    border: "7px solid #232623",
    radius: 54,
    shadow: "0 5px 10px #0004, inset 0 0 0 3px #ccc",
  },
} as const;

export const motionSpec = {
  revealFrames: 4,
  microBlurFrames: 3,
  sceneOverlapFrames: 4,
  captionWordFrames: 3,
  defaultEase: "cubic-bezier(0.22, 1, 0.36, 1)",
} as const;

export type ReferencePalette = typeof palette;
