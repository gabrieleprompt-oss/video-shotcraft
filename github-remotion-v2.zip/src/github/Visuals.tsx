import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { GithubMark } from "../components/GithubMark";
import { linear, mono, sans, tween } from "../theme";

export const C = {
  dark: "#0c0f0e",
  paper: "#f4f5f3",
  green: "#35d78b",
  greenInk: "#18794e",
  blue: "#539bf5",
  purple: "#b69af8",
  ink: "#181d1a",
  gray: "#8d9690",
};

export type IconName =
  | "code"
  | "repo"
  | "branch"
  | "commit"
  | "merge"
  | "check"
  | "star"
  | "fork"
  | "file"
  | "arrow"
  | "pull"
  | "people"
  | "chevron";
const paths: Record<IconName, string> = {
  code: "M8 6L2 12l6 6M16 6l6 6-6 6M14 3l-4 18",
  repo: "M5 3h15v18H5a2 2 0 0 1 0-4h15M5 3a2 2 0 0 0-2 2v14M8 7h8M8 10h6",
  branch:
    "M6 7v10M18 7v3a5 5 0 0 1-5 5H6M9 4a3 3 0 1 1-6 0 3 3 0 0 1 6 0M9 20a3 3 0 1 1-6 0 3 3 0 0 1 6 0M21 4a3 3 0 1 1-6 0 3 3 0 0 1 6 0",
  commit: "M1 12h6M17 12h6M17 12a5 5 0 1 1-10 0 5 5 0 0 1 10 0",
  merge:
    "M6 7v10M18 17v-3a5 5 0 0 0-5-5H6M9 4a3 3 0 1 1-6 0 3 3 0 0 1 6 0M9 20a3 3 0 1 1-6 0 3 3 0 0 1 6 0M21 20a3 3 0 1 1-6 0 3 3 0 0 1 6 0",
  pull: "M6 7v10M18 17V7h-5M13 7l3-3M13 7l3 3M9 4a3 3 0 1 1-6 0 3 3 0 0 1 6 0M9 20a3 3 0 1 1-6 0 3 3 0 0 1 6 0M21 20a3 3 0 1 1-6 0 3 3 0 0 1 6 0",
  check: "M5 12l4 4L20 5",
  star: "M12 2l3.1 6.3 7 1-5 5 1.1 7-6.2-3.3L5.8 21l1.1-6.8-5-5 7-1Z",
  fork: "M6 7v2a6 6 0 0 0 6 6m6-8v2a6 6 0 0 1-6 6v3M9 4a3 3 0 1 1-6 0 3 3 0 0 1 6 0M21 4a3 3 0 1 1-6 0 3 3 0 0 1 6 0M15 21a3 3 0 1 1-6 0 3 3 0 0 1 6 0",
  file: "M5 2h9l5 5v15H5ZM14 2v6h5M8 13h8M8 17h6",
  arrow: "M4 12h16M14 6l6 6-6 6",
  people:
    "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M15 3a4 4 0 0 1 0 8M22 21v-2a4 4 0 0 0-3-3.9M13 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0",
  chevron: "M8 5l7 7-7 7",
};
export const Icon = ({
  name,
  size = 30,
  color = "currentColor",
}: {
  name: IconName;
  size?: number;
  color?: string;
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke={color}
    strokeWidth="1.65"
    strokeLinecap="round"
    strokeLinejoin="round"
    style={{ flexShrink: 0 }}
  >
    <path d={paths[name]} />
  </svg>
);

export const Backdrop = ({
  dark = false,
  children,
}: {
  dark?: boolean;
  children?: React.ReactNode;
}) => (
  <AbsoluteFill
    style={{
      background: dark ? C.dark : C.paper,
      color: dark ? "#f3f6f3" : C.ink,
      fontFamily: sans,
      overflow: "hidden",
    }}
  >
    <AbsoluteFill
      style={{
        background: dark
          ? "radial-gradient(ellipse at 50% 58%, #24362d70 0%, transparent 58%)"
          : "radial-gradient(ellipse at 50% 47%, #fff 0%, transparent 62%)",
        pointerEvents: "none",
      }}
    />
    {children}
  </AbsoluteFill>
);

export const FadeScene = ({ children }: { children: React.ReactNode }) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{ opacity: linear(f, 0, 4) }}>{children}</AbsoluteFill>
  );
};

type TitleWord = { text: string; at?: number; selected?: boolean };
export const Title = ({
  lines,
  dark = false,
  size = 84,
  start = 0,
  end,
}: {
  lines: TitleWord[][];
  dark?: boolean;
  size?: number;
  start?: number;
  end?: number;
}) => {
  const f = useCurrentFrame() - start + 2;
  let index = 0;
  return (
    <div
      data-title
      style={{
        position: "absolute",
        left: 60,
        right: 60,
        top: 190,
        fontSize: size,
        lineHeight: 1.14,
        letterSpacing: -2.8,
        textAlign: "center",
        fontFamily: sans,
        zIndex: 30,
        opacity: end === undefined ? 1 : 1 - linear(f, end - 6, end),
      }}
    >
      {lines.map((line, n) => (
        <div
          key={n}
          style={{
            height: size * 1.23,
            whiteSpace: "nowrap",
            display: "flex",
            alignItems: "flex-start",
            justifyContent: "center",
            gap: "0.27em",
          }}
        >
          {line.map((word, j) => {
            const at = word.at ?? index++ * 3;
            const p = tween(f, at, at + 5);
            return (
              <span
                key={j}
                style={{
                  position: "relative",
                  display: "inline-block",
                  opacity: p,
                  translate: `0 ${18 * (1 - p)}px`,
                  filter: `blur(${3 * (1 - p)}px)`,
                  fontWeight: word.selected ? 700 : 400,
                  color: dark
                    ? word.selected
                      ? "#f7faf7"
                      : "#aab4ac"
                    : word.selected
                      ? "#111813"
                      : "#7e8780",
                }}
              >
                {word.text}
                {word.selected ? (
                  <span
                    style={{
                      position: "absolute",
                      inset: "2px -7px -2px",
                      border: `2px solid ${C.blue}`,
                      background: "#539bf509",
                      opacity: tween(f, at + 4, at + 9),
                      pointerEvents: "none",
                    }}
                  >
                    <i
                      style={{
                        position: "absolute",
                        left: -5,
                        top: -5,
                        width: 9,
                        height: 9,
                        background: C.blue,
                        border: "1px solid #cfe5ff",
                      }}
                    />
                    <i
                      style={{
                        position: "absolute",
                        right: -5,
                        bottom: -5,
                        width: 9,
                        height: 9,
                        background: C.blue,
                        border: "1px solid #cfe5ff",
                      }}
                    />
                  </span>
                ) : null}
              </span>
            );
          })}
        </div>
      ))}
    </div>
  );
};

export const Label = ({
  children,
  color = C.gray,
  style,
}: {
  children: React.ReactNode;
  color?: string;
  style?: React.CSSProperties;
}) => (
  <div style={{ fontFamily: mono, fontSize: 23, color, ...style }}>
    {children}
  </div>
);

export const Pill = ({
  children,
  icon,
  dark = false,
  accent = false,
}: {
  children: React.ReactNode;
  icon?: IconName;
  dark?: boolean;
  accent?: boolean;
}) => (
  <div
    style={{
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      gap: 12,
      padding: "13px 22px",
      borderRadius: 8,
      background: accent
        ? dark
          ? "#173b28"
          : "#daf4e6"
        : dark
          ? "#1d2520"
          : "#fff",
      border: `1px solid ${accent ? (dark ? "#315e43" : "#b9dfc9") : dark ? "#3c4740" : "#d8ded9"}`,
      color: accent
        ? dark
          ? C.green
          : C.greenInk
        : dark
          ? "#dce5dd"
          : "#56615a",
      fontFamily: mono,
      fontSize: 25,
    }}
  >
    {icon ? <Icon name={icon} size={26} /> : null}
    {children}
  </div>
);

export const Profile = ({
  name,
  color,
  size = 60,
}: {
  name: string;
  color: string;
  size?: number;
}) => (
  <div
    style={{
      width: size,
      height: size,
      borderRadius: "50%",
      background: `linear-gradient(140deg, #ffffff15, #00000012), ${color}`,
      color: "#fff",
      border: "3px solid #ffffffbb",
      boxShadow: "0 3px 8px #0001",
      display: "grid",
      placeItems: "center",
      fontSize: size * 0.42,
      fontFamily: sans,
      fontWeight: 700,
      flexShrink: 0,
    }}
  >
    {name.slice(0, 1)}
  </div>
);

export const Panel = ({
  children,
  dark = false,
  style,
}: {
  children: React.ReactNode;
  dark?: boolean;
  style?: React.CSSProperties;
}) => (
  <div
    style={{
      background: dark ? "#161d18" : "#ffffff",
      color: dark ? "#edf3ed" : C.ink,
      border: `1px solid ${dark ? "#38473b" : "#dfe4de"}`,
      borderRadius: 12,
      boxShadow: dark
        ? "0 38px 60px #0006, 0 1px 0 #ffffff10 inset"
        : "0 32px 54px #263b2520, 0 2px 4px #14261710",
      overflow: "hidden",
      ...style,
    }}
  >
    {children}
  </div>
);

export const WindowBar = ({
  file,
  dark = false,
  right,
}: {
  file: string;
  dark?: boolean;
  right?: React.ReactNode;
}) => (
  <div
    style={{
      height: 76,
      padding: "0 25px",
      display: "flex",
      gap: 12,
      alignItems: "center",
      background: dark ? "#202922" : "#f4f6f3",
      borderBottom: `1px solid ${dark ? "#364139" : "#e0e5df"}`,
      fontFamily: mono,
      fontSize: 25,
      color: dark ? "#c4cfc6" : "#57625a",
    }}
  >
    <Icon name="file" size={24} />
    {file}
    {right ? <span style={{ marginLeft: "auto" }}>{right}</span> : null}
  </div>
);

export const CodeLines = ({
  lines,
  dark = true,
  fontSize = 27,
  reveal = 1,
}: {
  lines: readonly string[];
  dark?: boolean;
  fontSize?: number;
  reveal?: number;
}) => (
  <div
    style={{
      padding: "23px 26px",
      fontFamily: mono,
      fontSize,
      lineHeight: 1.8,
      whiteSpace: "pre",
      color: dark ? "#dae4dd" : "#536459",
    }}
  >
    {lines.map((line, i) => (
      <div key={i} style={{ opacity: reveal >= i / lines.length ? 1 : 0 }}>
        <span
          style={{
            display: "inline-block",
            width: 48,
            color: dark ? "#52675b" : "#a5afa7",
            userSelect: "none",
          }}
        >
          {i + 1}
        </span>
        <span
          style={{
            color: line.startsWith("//")
              ? dark
                ? "#6c8977"
                : "#7a9584"
              : line.includes("return")
                ? dark
                  ? "#bca5eb"
                  : "#8d53ba"
                : line.includes("const")
                  ? dark
                    ? "#96bfed"
                    : "#3575b7"
                  : undefined,
          }}
        >
          {line}
        </span>
      </div>
    ))}
  </div>
);

export const CodeTile = ({
  filename = "app.tsx",
  dark = true,
  width = 650,
  lines = [
    "const app = createApp();",
    "",
    "export function App() {",
    "  return <Hello />;",
    "}",
  ],
}: {
  filename?: string;
  dark?: boolean;
  width?: number;
  lines?: readonly string[];
}) => (
  <Panel dark={dark} style={{ width }}>
    <WindowBar
      file={filename}
      dark={dark}
      right={<Icon name="code" size={26} color={C.green} />}
    />
    <CodeLines lines={lines} dark={dark} />
  </Panel>
);

export const RepoCard = ({
  progress = 1,
  compact = false,
  dark = false,
}: {
  progress?: number;
  compact?: boolean;
  dark?: boolean;
}) => (
  <Panel dark={dark} style={{ width: 900, borderRadius: 12 }}>
    <div
      style={{
        padding: "28px 29px 23px",
        display: "flex",
        alignItems: "center",
        gap: 15,
      }}
    >
      <GithubMark size={43} color={dark ? "#f2f7f2" : "#242c26"} />
      <div style={{ fontSize: 29 }}>
        <span style={{ color: dark ? "#a5b4a9" : "#748078" }}>équipe / </span>
        <b>mon-projet</b>
      </div>
      <span
        style={{
          fontFamily: mono,
          fontSize: 18,
          color: "#8c978f",
          border: `1px solid ${dark ? "#48564c" : "#ccd5cf"}`,
          padding: "4px 11px",
          borderRadius: 20,
        }}
      >
        Public
      </span>
    </div>
    <div
      style={{
        display: "flex",
        gap: 28,
        padding: "0 30px",
        height: 66,
        alignItems: "center",
        borderBottom: `1px solid ${dark ? "#38463c" : "#dce2dd"}`,
        fontSize: 23,
      }}
    >
      <span
        style={{
          display: "flex",
          alignItems: "center",
          gap: 9,
          height: "100%",
          borderBottom: "3px solid #e39177",
        }}
      >
        <Icon name="code" size={24} />
        Code
      </span>
      <span style={{ color: "#7a8a7e" }}>
        Issues <b style={{ fontSize: 18 }}>3</b>
      </span>
      <span style={{ color: "#7a8a7e" }}>
        Pull requests <b style={{ fontSize: 18 }}>2</b>
      </span>
    </div>
    {!compact ? (
      <>
        <div
          style={{
            padding: "22px 28px",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Pill dark={dark} icon="branch">
            main
          </Pill>
          <div
            style={{
              background: "#23814b",
              padding: "14px 24px",
              borderRadius: 7,
              color: "#fff",
              fontSize: 24,
              display: "flex",
              alignItems: "center",
              gap: 12,
            }}
          >
            <Icon name="code" size={22} />
            Code
          </div>
        </div>
        <div
          style={{
            margin: "0 28px",
            border: `1px solid ${dark ? "#3b493f" : "#dfe4df"}`,
            borderRadius: 8,
            overflow: "hidden",
          }}
        >
          <div
            style={{
              background: dark ? "#202c24" : "#f0f5f0",
              display: "flex",
              alignItems: "center",
              gap: 13,
              height: 65,
              padding: "0 20px",
              fontSize: 20,
            }}
          >
            <Profile name="Léa" color="#678b9c" size={32} />
            <b>Léa</b>
            <span style={{ color: "#7a8b7e" }}>Initial commit</span>
            <span
              style={{
                marginLeft: "auto",
                fontFamily: mono,
                fontSize: 17,
                color: "#7a8b7e",
              }}
            >
              a4f91c2
            </span>
          </div>
          {["src/", "app.tsx", "README.md", "package.json"].map((file, i) => (
            <div
              key={file}
              style={{
                opacity: linear(progress, i * 0.2, i * 0.2 + 0.12),
                translate: `${20 * (1 - tween(progress, i * 0.2, i * 0.2 + 0.2))}px 0`,
                height: 65,
                display: "flex",
                alignItems: "center",
                gap: 15,
                padding: "0 22px",
                borderTop: `1px solid ${dark ? "#2f3f33" : "#e7ebe7"}`,
                fontFamily: mono,
                fontSize: 25,
              }}
            >
              <Icon
                name="file"
                size={23}
                color={i === 0 ? "#69a7d8" : "#879e8c"}
              />
              {file}
              <span
                style={{
                  marginLeft: "auto",
                  color: "#7a8b7e",
                  fontFamily: sans,
                  fontSize: 20,
                }}
              >
                à l’instant
              </span>
            </div>
          ))}
        </div>
        <div
          style={{
            padding: "23px 28px",
            fontFamily: mono,
            color: dark ? C.green : C.greenInk,
            fontSize: 20,
            display: "flex",
            alignItems: "center",
            gap: 10,
          }}
        >
          <Icon name="check" size={22} />
          {progress >= 0.8
            ? "Tous les fichiers sont enregistrés"
            : "Enregistrement des fichiers…"}
        </div>
      </>
    ) : (
      <div
        style={{
          padding: "22px 30px",
          display: "flex",
          alignItems: "center",
          gap: 12,
          color: dark ? C.green : C.greenInk,
          fontFamily: mono,
          fontSize: 23,
        }}
      >
        <Icon name="branch" size={25} />
        main{" "}
        <span style={{ color: "#7a8b7e", marginLeft: "auto" }}>
          3 contributeurs
        </span>
      </div>
    )}
  </Panel>
);

export const Deck = ({
  children,
  width,
  height,
  frame,
  dark = false,
  entrance = true,
  flatten = 0,
}: {
  children: React.ReactNode;
  width: number;
  height: number;
  frame: number;
  dark?: boolean;
  entrance?: boolean;
  flatten?: number;
}) => {
  const p = entrance ? tween(frame, 0, 22) : 1;
  return (
    <div
      style={{
        width,
        height,
        position: "relative",
        transform: `perspective(1700px) rotateX(${(9 + 10 * (1 - p)) * (1 - flatten)}deg) rotateY(${tween(frame, 0, 110, -8, 3) * (1 - flatten)}deg) rotateZ(${tween(frame, 0, 110, -3, -0.5) * (1 - flatten)}deg)`,
        transformStyle: "preserve-3d",
        opacity: p,
        translate: `0 ${70 * (1 - p)}px`,
      }}
    >
      {[20, 15, 10, 5].map((z) => (
        <div
          key={z}
          style={{
            position: "absolute",
            inset: 0,
            translate: `0 ${z * (1 - flatten)}px`,
            borderRadius: 14,
            background: dark ? "#24332a" : "#d2d9d1",
            border: `1px solid ${dark ? "#49584d" : "#b9c5b8"}`,
            boxShadow: z === 20 ? "0 60px 70px #0002" : undefined,
          }}
        />
      ))}
      <div style={{ position: "relative" }}>{children}</div>
    </div>
  );
};

export const SectionFooter = ({
  active,
  dark = false,
}: {
  active: number;
  dark?: boolean;
}) => (
  <div
    style={{
      position: "absolute",
      left: 90,
      right: 90,
      top: 1650,
      display: "flex",
      alignItems: "center",
      gap: 0,
      fontFamily: mono,
      zIndex: 35,
    }}
  >
    {(
      [
        ["code", "CODE"],
        ["people", "ÉQUIPE"],
        ["commit", "HISTORIQUE"],
      ] as const
    ).map(([icon, label], i) => (
      <React.Fragment key={label}>
        {i > 0 ? (
          <div
            style={{
              height: 1,
              flex: 1,
              background: dark ? "#34443a" : "#d2dcd3",
              margin: "0 25px",
            }}
          />
        ) : null}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
            color:
              active === i
                ? dark
                  ? C.green
                  : C.greenInk
                : dark
                  ? "#56675d"
                  : "#aab5ac",
            fontSize: 20,
          }}
        >
          <Icon name={icon} size={27} />
          {label}
        </div>
      </React.Fragment>
    ))}
  </div>
);
