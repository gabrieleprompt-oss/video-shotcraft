import React from "react";
import { useCurrentFrame } from "remotion";
import { linear, mono, tween } from "../theme";
import {
  Backdrop,
  FadeScene,
  Icon,
  Panel,
  Pill,
  Profile,
  RepoCard,
  SectionFooter,
  Title,
} from "./Visuals";

const Contribution = ({
  name,
  color,
  filename,
  code,
  f,
  delay,
}: {
  name: string;
  color: string;
  filename: string;
  code: string;
  f: number;
  delay: number;
}) => (
  <Panel
    style={{
      width: 286,
      opacity: tween(f, delay, delay + 13),
      translate: `0 ${tween(f, delay, delay + 13, 70, 0)}px`,
    }}
  >
    <div
      style={{
        padding: "21px 20px 16px",
        display: "flex",
        alignItems: "center",
        gap: 12,
      }}
    >
      <Profile name={name} color={color} size={43} />
      <b style={{ fontSize: 25 }}>{name}</b>
    </div>
    <div
      style={{
        fontFamily: mono,
        color: "#6c7b71",
        fontSize: 21,
        padding: "0 21px 17px",
      }}
    >
      {filename}
    </div>
    <div
      style={{
        fontFamily: mono,
        fontSize: 20,
        padding: "19px 20px",
        borderTop: "1px solid #dfe7e0",
        background: "#f3f7f2",
        color,
        whiteSpace: "pre",
      }}
    >
      {code}
    </div>
    <div
      style={{
        padding: "16px 20px",
        color: "#6a7d6e",
        fontFamily: mono,
        fontSize: 18,
        display: "flex",
        alignItems: "center",
        gap: 8,
      }}
    >
      <Icon name="commit" size={21} />
      {linear(f, delay + 18, delay + 27) >= 1 ? "commit envoyé" : "en cours…"}
    </div>
  </Panel>
);

export const GithubCollaborationV2 = () => {
  const f = useCurrentFrame();
  return (
    <FadeScene>
      <Backdrop>
        <Title
          end={120}
          size={80}
          lines={[
            [
              { text: "travailler" },
              { text: "à plusieurs", selected: true, at: 5 },
            ],
            [{ text: "sur un projet.", at: 13 }],
          ]}
        />
        <div
          style={{
            position: "absolute",
            left: 90,
            top: 560,
            scale: 0.94,
            transformOrigin: "center top",
          }}
        >
          <RepoCard compact />
        </div>
        <svg
          width="1080"
          height="660"
          viewBox="0 0 1080 660"
          style={{ position: "absolute", top: 800, left: 0 }}
        >
          {[
            { x: 219, c: "#658ba6", d: 20 },
            { x: 540, c: "#9b7bc0", d: 27 },
            { x: 861, c: "#b78e5c", d: 34 },
          ].map(({ x, c, d }) => (
            <g key={x}>
              <path
                d={`M${x} 260V180Q${x} 120 ${x < 540 ? x + 60 : x > 540 ? x - 60 : x} 120H${x < 540 ? 480 : x > 540 ? 600 : 540}Q540 120 540 60V0`}
                pathLength="1"
                stroke={c}
                strokeWidth="4"
                fill="none"
                strokeDasharray="1"
                strokeDashoffset={1 - tween(f, d, d + 18)}
              />
              <circle
                cx={x}
                cy={tween(f, d + 35, d + 61, 260, 120)}
                r="10"
                fill={c}
                opacity={
                  tween(f, d + 34, d + 37) * (1 - tween(f, d + 55, d + 62))
                }
              />
              <circle
                cx={tween(f, d + 53, d + 74, x, 540)}
                cy={tween(f, d + 53, d + 74, 120, 25)}
                r="9"
                fill={c}
                opacity={
                  tween(f, d + 53, d + 57) * (1 - tween(f, d + 72, d + 77))
                }
              />
            </g>
          ))}
        </svg>
        <div
          style={{
            position: "absolute",
            top: 1065,
            left: 76,
            display: "flex",
            gap: 35,
          }}
        >
          <Contribution
            name="Léa"
            color="#658ba6"
            filename="interface.tsx"
            code={"+ <Button />\n+ <Header />"}
            f={f}
            delay={6}
          />
          <Contribution
            name="Malik"
            color="#9b7bc0"
            filename="api.ts"
            code={"+ getUsers()\n+ saveData()"}
            f={f}
            delay={12}
          />
          <Contribution
            name="Jules"
            color="#b78e5c"
            filename="style.css"
            code={"+ .button {\n+  color: #fff; }"}
            f={f}
            delay={18}
          />
        </div>
        <div
          style={{
            position: "absolute",
            top: 1435,
            left: 0,
            right: 0,
            display: "flex",
            justifyContent: "center",
            opacity: tween(f, 96, 109),
            scale: tween(f, 96, 109, 0.9, 1),
          }}
        >
          <Pill accent icon="merge">
            Code réuni sur main
          </Pill>
        </div>
        <SectionFooter active={1} />
      </Backdrop>
    </FadeScene>
  );
};
