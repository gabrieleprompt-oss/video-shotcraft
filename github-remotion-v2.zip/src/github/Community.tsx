import React from "react";
import { useCurrentFrame } from "remotion";
import { GithubMark } from "../components/GithubMark";
import { mono, tween } from "../theme";
import { Backdrop, C, FadeScene, Icon, Profile, Title } from "./Visuals";

const people = [
  {
    x: 185,
    y: 670,
    name: "Léa",
    color: "#658ba6",
    action: "review",
    icon: "check" as const,
  },
  {
    x: 815,
    y: 620,
    name: "Malik",
    color: "#9877b7",
    action: "fork",
    icon: "fork" as const,
  },
  {
    x: 120,
    y: 1150,
    name: "Jules",
    color: "#ab8357",
    action: "commit",
    icon: "commit" as const,
  },
  {
    x: 830,
    y: 1160,
    name: "Alice",
    color: "#5d9a80",
    action: "pull request",
    icon: "pull" as const,
  },
];

export const GithubCommunityV2 = () => {
  const f = useCurrentFrame();
  const finale = tween(f, 67, 92);
  return (
    <FadeScene>
      <Backdrop dark>
        <Title
          dark
          size={77}
          lines={[
            [{ text: "En gros, c’est le" }],
            [{ text: "réseau social", selected: true, at: 4 }],
            [{ text: "des développeurs.", at: 13 }],
          ]}
        />
        <svg
          width="1080"
          height="1150"
          viewBox="0 0 1080 1150"
          style={{ position: "absolute", top: 450 }}
        >
          <ellipse
            cx="540"
            cy="490"
            rx="370"
            ry="310"
            fill="none"
            stroke="#27392d"
            strokeWidth="1.5"
          />
          <ellipse
            cx="540"
            cy="490"
            rx="465"
            ry="440"
            fill="none"
            stroke="#1c2d22"
            strokeWidth="1"
          />
          {people.map((p, i) => (
            <path
              key={p.name}
              d={`M${p.x + 56} ${p.y - 450 + 48}Q540 ${p.y < 900 ? 80 : 1050} 540 490`}
              stroke={p.color}
              strokeWidth="2.5"
              fill="none"
              opacity={0.45 * tween(f, i * 5 + 6, i * 5 + 22)}
              pathLength="1"
              strokeDasharray="1"
              strokeDashoffset={1 - tween(f, i * 5 + 6, i * 5 + 30)}
            />
          ))}
          {[0, 1, 2, 3, 4].map((i) => (
            <circle
              key={i}
              cx={140 + i * 191}
              cy={480 + (i % 2) * 330}
              r="4"
              fill="#72977f"
              opacity=".6"
            />
          ))}
        </svg>
        {people.map((p, i) => (
          <div
            key={p.name}
            style={{
              position: "absolute",
              left: p.x,
              top: p.y + Math.sin(f / 33 + i) * 8,
              opacity: tween(f, i * 5, i * 5 + 16),
              scale: tween(f, i * 5, i * 5 + 20, 0.8, 1),
              width: 150,
              textAlign: "center",
            }}
          >
            <div style={{ display: "flex", justifyContent: "center" }}>
              <Profile size={90} name={p.name} color={p.color} />
            </div>
            <div style={{ marginTop: 12, fontSize: 26, color: "#c1cec3" }}>
              {p.name}
            </div>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                gap: 7,
                marginTop: 13,
                color: p.color,
                fontFamily: mono,
                fontSize: 19,
              }}
            >
              <Icon name={p.icon} size={22} />
              {p.action}
            </div>
          </div>
        ))}
        <div
          style={{
            position: "absolute",
            left: 349,
            top: 817,
            width: 382,
            height: 307,
            transform: `perspective(1200px) rotateX(${tween(f, 0, 70, 15, 0)}deg) rotateY(${tween(f, 0, 70, -12, 0)}deg) scale(${tween(f, 0, 70, 0.7, 1)})`,
            opacity: tween(f, 0, 15),
          }}
        >
          {[18, 12, 6, 0].map((z) => (
            <div
              key={z}
              style={{
                position: "absolute",
                inset: 0,
                translate: `0 ${z}px`,
                borderRadius: 33,
                border: `1px solid ${z ? "#3a5a43" : "#b7c9bb"}`,
                background: z
                  ? "#25392c"
                  : "linear-gradient(130deg,#fafcf9,#b3c4b7)",
                boxShadow: z === 18 ? "0 45px 55px #0009" : undefined,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              {z === 0 ? <GithubMark size={230} color="#122219" /> : null}
            </div>
          ))}
        </div>
        <div
          style={{
            position: "absolute",
            top: 1435,
            left: 0,
            right: 0,
            textAlign: "center",
            fontSize: 42,
            color: "#e6eee7",
            letterSpacing: -0.5,
            opacity: finale,
            translate: `0 ${24 * (1 - finale)}px`,
          }}
        >
          Ton code. Ton équipe. <b style={{ color: C.green }}>Ta communauté.</b>
        </div>
        <div
          style={{
            position: "absolute",
            top: 1580,
            left: 355,
            right: 355,
            height: 1,
            background: "#496350",
            opacity: finale,
          }}
        />
        <div
          style={{
            position: "absolute",
            top: 1650,
            left: 0,
            right: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 14,
            fontFamily: mono,
            fontSize: 27,
            color: "#9ab19f",
            opacity: finale,
          }}
        >
          <Icon name="code" size={29} />
          github.com
        </div>
      </Backdrop>
    </FadeScene>
  );
};
