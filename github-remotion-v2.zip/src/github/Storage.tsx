import React from "react";
import { useCurrentFrame } from "remotion";
import { linear, tween } from "../theme";
import {
  Backdrop,
  C,
  CodeTile,
  Deck,
  FadeScene,
  Icon,
  Pill,
  RepoCard,
  SectionFooter,
  Title,
} from "./Visuals";

export const GithubStorageV2 = () => {
  const f = useCurrentFrame();
  const dock = tween(f, 30, 63);
  const collapse = tween(f, 103, 122);
  return (
    <FadeScene>
      <Backdrop>
        {f < 43 ? (
          <Title
            end={43}
            lines={[
              [{ text: "C’est une" }],
              [{ text: "plateforme", selected: true, at: 6 }],
            ]}
          />
        ) : (
          <Title
            start={43}
            end={77}
            size={78}
            lines={[
              [{ text: "où tu peux" }],
              [{ text: "stocker ton code,", selected: true, at: 4 }],
            ]}
          />
        )}
        <div
          style={{
            position: "absolute",
            left: 90,
            top: 660 + tween(f, 0, 60, 150, 0) - collapse * 100,
            scale: tween(f, 0, 45, 0.86, 1) - collapse * 0.06,
            transformOrigin: "center top",
          }}
        >
          <Deck
            width={900}
            height={647 - collapse * 413}
            frame={f}
            flatten={collapse}
          >
            <div
              style={{
                height: 647 - collapse * 413,
                overflow: "hidden",
                borderRadius: 12,
                opacity: 1 - tween(f, 106, 118),
              }}
            >
              <RepoCard progress={linear(f, 42, 82)} />
            </div>
            <div
              style={{
                position: "absolute",
                inset: "0 0 auto",
                opacity: tween(f, 110, 122),
              }}
            >
              <RepoCard compact />
            </div>
          </Deck>
        </div>
        <div
          style={{
            position: "absolute",
            left: tween(f, 30, 64, 180, 220),
            top: tween(f, 30, 64, 515, 1040),
            scale: tween(f, 30, 64, 1, 0.19),
            opacity: 1 - tween(f, 58, 68),
            rotate: `${tween(f, 30, 64, -7, 0)}deg`,
            filter: `blur(${tween(f, 54, 64, 0, 3)}px)`,
            transformOrigin: "top left",
            zIndex: 5,
          }}
        >
          <CodeTile
            width={720}
            lines={[
              "// ton application",
              "const message = 'Bonjour !';",
              "",
              "export function App() {",
              "  return <h1>{message}</h1>;",
              "}",
            ]}
          />
        </div>
        {f < 70 ? (
          <div
            style={{
              position: "absolute",
              left: 460,
              top: 1170,
              opacity: tween(f, 20, 29) * (1 - dock),
              color: C.greenInk,
            }}
          >
            <Icon name="arrow" size={55} />
          </div>
        ) : null}
        <div
          style={{
            position: "absolute",
            left: 0,
            right: 0,
            top: 1430,
            display: "flex",
            justifyContent: "center",
            opacity: tween(f, 72, 87) * (1 - collapse),
            translate: `0 ${tween(f, 72, 87, 22, 0)}px`,
          }}
        >
          <Pill accent icon="check">
            Ton code, au même endroit
          </Pill>
        </div>
        <SectionFooter active={0} />
      </Backdrop>
    </FadeScene>
  );
};
