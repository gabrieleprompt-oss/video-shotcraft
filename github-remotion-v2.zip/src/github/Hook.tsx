import React from "react";
import { useCurrentFrame } from "remotion";
import { GithubMark } from "../components/GithubMark";
import { mono, tween } from "../theme";
import { Backdrop, C, CodeTile, Title } from "./Visuals";

export const GithubHookV2 = () => {
  const f = useCurrentFrame();
  return (
    <Backdrop dark>
      <div
        style={{
          position: "absolute",
          width: 900,
          height: 200,
          left: 90,
          top: 1160,
          borderRadius: "50%",
          background: "#607e6930",
          filter: "blur(38px)",
          scale: tween(f, 0, 66, 0.8, 1.15),
        }}
      />
      {[
        { x: -230, y: 500, s: 0.7, r: -13 },
        { x: 690, y: 560, s: 0.61, r: 13 },
        { x: -90, y: 1190, s: 0.5, r: 7 },
        { x: 750, y: 1200, s: 0.45, r: -8 },
      ].map((v, i) => (
        <div
          key={i}
          style={{
            position: "absolute",
            left: v.x,
            top: v.y + Math.sin(f / 34 + i) * 14,
            opacity: 0.16 + tween(f, 0, 24) * 0.18,
            filter: "blur(3px)",
            scale: v.s,
            transformOrigin: "top left",
            rotate: `${v.r}deg`,
          }}
        >
          <CodeTile width={500} />
        </div>
      ))}
      <Title
        end={66}
        dark
        lines={[
          [{ text: "GitHub,", selected: true }],
          [{ text: "c’est quoi ?", at: 9 }],
        ]}
        size={102}
      />
      <div
        style={{
          position: "absolute",
          left: 233,
          top: 655,
          width: 614,
          height: 545,
          opacity: tween(f, -4, 8),
          transform: `perspective(1400px) rotateX(${tween(f, 0, 50, 20, 9)}deg) rotateY(${tween(f, 0, 50, -22, -5)}deg) rotateZ(${tween(f, 0, 50, -9, -3)}deg) scale(${tween(f, 0, 50, 0.8, 1.06)})`,
        }}
      >
        {[42, 35, 28, 21, 14, 7, 0].map((z) => (
          <div
            key={z}
            style={{
              position: "absolute",
              inset: 0,
              top: z,
              bottom: -z,
              borderRadius: 62,
              background: z
                ? "linear-gradient(110deg,#4d5e53,#141f18 65%,#3e4b43)"
                : "linear-gradient(135deg,#f8faf7,#c9d2c9)",
              border: `2px solid ${z ? "#5c6b60" : "#ffffff"}`,
              boxShadow:
                z === 42 ? "0 65px 90px #0009" : "inset 0 1px 2px #ffffff88",
              display: "grid",
              placeItems: "center",
            }}
          >
            {z === 0 ? <GithubMark size={384} color="#15231a" /> : null}
          </div>
        ))}
      </div>
      <div
        style={{
          position: "absolute",
          top: 1330,
          width: "100%",
          textAlign: "center",
          fontFamily: mono,
          fontSize: 29,
          letterSpacing: 6,
          color: "#9caf9f",
          opacity: tween(f, 18, 28),
        }}
      >
        LE CODE. ENSEMBLE.
      </div>
      <div
        style={{
          position: "absolute",
          left: 430,
          top: 1480,
          width: tween(f, 25, 50, 0, 220),
          height: 3,
          background: C.green,
          opacity: 0.8,
        }}
      />
    </Backdrop>
  );
};
