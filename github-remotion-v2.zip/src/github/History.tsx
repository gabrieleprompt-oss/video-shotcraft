import React from "react";
import { useCurrentFrame } from "remotion";
import { linear, mono, tween } from "../theme";
import {
  Backdrop,
  C,
  FadeScene,
  Icon,
  Panel,
  Pill,
  SectionFooter,
  Title,
  WindowBar,
} from "./Visuals";

export const GithubHistoryV2 = () => {
  const f = useCurrentFrame();
  const change = tween(f, 24, 42);
  const approve = tween(f, 71, 85);
  return (
    <FadeScene>
      <Backdrop dark>
        <Title
          end={120}
          dark
          size={81}
          lines={[
            [{ text: "et suivre toutes" }],
            [{ text: "les modifications.", selected: true, at: 7 }],
          ]}
        />
        <div
          style={{
            position: "absolute",
            left: 65,
            top: 575,
            opacity: tween(f, 0, 12),
            translate: `0 ${tween(f, 0, 20, 65, 0)}px`,
            transform: `perspective(1800px) rotateY(${tween(f, 0, 75, -5, 0)}deg) rotateX(3deg)`,
          }}
        >
          <Panel dark style={{ width: 950 }}>
            <WindowBar
              dark
              file="app.tsx"
              right={
                <span style={{ fontSize: 23, color: C.green }}>
                  +2 <span style={{ color: "#f0958a" }}>−2</span>
                </span>
              }
            />
            <div
              style={{
                padding: "23px 25px",
                color: "#b0bfb4",
                fontFamily: mono,
                fontSize: 24,
                borderBottom: "1px solid #334338",
                display: "flex",
                gap: 15,
                alignItems: "center",
              }}
            >
              <Icon name="pull" color={C.green} size={28} />
              Améliorer le message d’accueil{" "}
              <span style={{ marginLeft: "auto", color: "#697f70" }}>#12</span>
            </div>
            <div
              style={{
                padding: "27px 0",
                fontFamily: mono,
                fontSize: 27,
                lineHeight: 1.9,
                whiteSpace: "pre",
              }}
            >
              <div style={{ padding: "0 25px", color: "#8d9f92" }}>
                1 export function App() {"{"}
              </div>
              <div
                style={{
                  background: "#6c30334d",
                  color: "#efaaa7",
                  padding: "0 25px",
                  opacity: tween(f, 10, 20),
                }}
              >
                − const title = 'Salut';
              </div>
              <div
                style={{
                  background: "#234f3288",
                  color: "#8fe2ab",
                  padding: "0 25px",
                  opacity: change,
                }}
              >
                + const title = 'Bonjour !';
              </div>
              <div
                style={{
                  background: "#6c30334d",
                  color: "#efaaa7",
                  padding: "0 25px",
                  opacity: tween(f, 10, 20),
                }}
              >
                − return &lt;h2&gt;{"{title}"}&lt;/h2&gt;;
              </div>
              <div
                style={{
                  background: "#234f3288",
                  color: "#8fe2ab",
                  padding: "0 25px",
                  opacity: change,
                }}
              >
                + return &lt;h1&gt;{"{title}"}&lt;/h1&gt;;
              </div>
              <div style={{ padding: "0 25px", color: "#8d9f92" }}>6 {"}"}</div>
            </div>
            <div
              style={{
                padding: "21px 25px",
                borderTop: "1px solid #34453a",
                display: "flex",
                alignItems: "center",
                gap: 12,
                fontSize: 24,
                color: C.green,
              }}
            >
              <Icon name={approve > 0 ? "check" : "commit"} size={28} />
              <span style={{ opacity: 1 - approve }}>
                Vérification des changements…
              </span>
              <span
                style={{ opacity: approve, position: "absolute", left: 65 }}
              >
                Changements vérifiés et fusionnés
              </span>
            </div>
          </Panel>
        </div>
        <div style={{ position: "absolute", left: 95, top: 1290, width: 890 }}>
          <svg width="890" height="100" viewBox="0 0 890 100">
            <path d="M35 50H855" stroke="#344b3c" strokeWidth="4" />
            <path
              d="M35 50H855"
              stroke={C.green}
              strokeWidth="4"
              pathLength="1"
              strokeDasharray="1"
              strokeDashoffset={1 - linear(f, 28, 95)}
            />
            {[60, 445, 830].map((x) => (
              <g key={x}>
                <circle
                  cx={x}
                  cy="50"
                  r="17"
                  fill="#13241a"
                  stroke={
                    linear(f, 28, 95) >= (x - 35) / 820 ? C.green : "#3f5847"
                  }
                  strokeWidth="3"
                />
                <circle
                  cx={x}
                  cy="50"
                  r="6"
                  fill={
                    linear(f, 28, 95) >= (x - 35) / 820 ? C.green : "#3f5847"
                  }
                />
              </g>
            ))}
          </svg>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              fontFamily: mono,
              fontSize: 25,
              color: "#6e8978",
              padding: "0 28px",
            }}
          >
            <span style={{ color: f >= 31 ? C.green : undefined }}>
              v1 · départ
            </span>
            <span style={{ color: f >= 62 ? C.green : undefined }}>
              v2 · modifié
            </span>
            <span style={{ color: f >= 93 ? C.green : undefined }}>
              v3 · fusionné
            </span>
          </div>
        </div>
        <div
          style={{
            position: "absolute",
            top: 1490,
            left: 0,
            right: 0,
            display: "flex",
            justifyContent: "center",
            opacity: tween(f, 90, 105),
          }}
        >
          <Pill dark accent icon="commit">
            Qui a changé quoi, et quand.
          </Pill>
        </div>
        <SectionFooter active={2} dark />
      </Backdrop>
    </FadeScene>
  );
};
